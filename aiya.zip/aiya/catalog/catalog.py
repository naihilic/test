import ipywidgets as widgets
from IPython.display import display, HTML, clear_output, Pretty
from aiya.context.context import context as ctx
from aiya.ui import tools as uit
from aiya.constants import JSON_OPTION, CSV_OPTION
from aiya.utils.uploadutils import (
    getDfFromByte,
    get_properRadio,
    getMetaAndContent,
    makeCatalogName,
)
import os
import pandas as pd
from abc import ABC, abstractmethod


class BaseCatalog:
    def __init__(self):
        self.fileName = self.metaData = self.content = self.df = None
        self.dOption = {"sep": ",", "orient": "records"}
        self.loadLayout = widgets.GridspecLayout(2, 10)  # ,height='1200px').
        self.loadLayout[0, :4] = self.uploadOut = widgets.Output()
        self.loadLayout[0, 4:] = self.nullOut = widgets.Output()
        self.loadLayout[
            1, :
        ] = (
            self.resultOut
        ) = widgets.Output()  # layout = widgets.Layout(border='solid 2px'))

    def on_sepOption(self, change):
        if change["new"] in [x[1] for x in CSV_OPTION]:
            self.dOption["sep"] = change["new"]
        else:
            self.dOption["orient"] = change["new"]

    def addCatalog(self):
        if self.df is not None:
            ctx.newCatalog(self.fileName, self.metaData, self.df)
            with self.resultOut:
                clear_output()
                catalogName = makeCatalogName(self.fileName)
                display(widgets.Label("데이터 앞 부분 (Head)"))
                display(self.df.head())
            with self.nullOut:
                clear_output()
                display(
                    widgets.HBox(
                        [
                            widgets.Label("추가한 데이터 카탈로그 이름 : "),
                            widgets.Label(catalogName),
                        ]
                    )
                )
                display(
                    widgets.Label("Column 별 null 값 개수 "),
                    pd.DataFrame({"null_count": self.df.isnull().sum()}).T,
                )
        else:
            with self.resultOut:
                clear_output()
                display(widgets.Label("파일 형식과 구분자가 달라 업로드하지 못했습니다."))

    def displayPreview(self):
        with self.uploadOut:
            clear_output()
            display(
                widgets.HBox(
                    [widgets.Label("업로드 파일 이름 : "), widgets.Label(self.fileName)]
                )
            )
            rButtons = get_properRadio(self.content, self.dOption, self.fileName)
            if rButtons is not None:
                rButtons.observe(self.on_sepOption, names="value")
                display(rButtons)
            display(uit.createButton("추가하기", self.add_uploadedFile))

    def add_uploadedFile(self, btn):
        self.df = getDfFromByte(self.content, self.dOption, self.fileName)
        self.addCatalog()

    def displayWidgets(self):
        display(self.uploadFile)
        display(self.loadLayout)


class PCCatalog(BaseCatalog):
    def __init__(self):
        super().__init__()
        self.uploadFile = widgets.FileUpload(
            accept=".csv, .csv_, .json, .xls, .xlsx", multiple=False
        )
        self.uploadFile.observe(self.on_uploadFileComplete, names="value")

    def on_uploadFileComplete(self, data):
        uploaded_data = data["new"]
        self.fileName, self.metaData, self.content = getMetaAndContent(uploaded_data)
        self.displayPreview()


class AIduCatalog(BaseCatalog):
    def __init__(self):
        super().__init__()
        self.aiduLayout = widgets.GridspecLayout(1, 10)  # ,height='1200px').
        self.aiduLayout[0, :5] = self.dataOut = widgets.Output()
        self.aiduLayout[0, 5:] = self.otherOut = widgets.Output()

    def on_selFile(self, change):
        filePath = change["new"]
        with open(filePath, mode="rb") as file:
            self.content = file.read()
            self.fileName = filePath.stem
        self.displayPreview()

    def displayWidgets(self):
        from pathlib import Path

        basePath = Path(os.path.join(os.sep, "aihub"))
        dataPath = Path(os.path.join(basePath, "data"))
        allFiles = [
            (name, Path(os.path.join(dirPath, name)))
            for dirPath, dirNames, fileNames in os.walk(basePath)
            for name in fileNames
        ]
        dataFiles = []
        otherFiles = []
        for fileList in allFiles:
            if fileList[1].parent.absolute() == dataPath.absolute():
                dataFiles.append(fileList)

            else:
                if fileList[0].split(".")[-1] in [
                    "csv",
                    "csv_",
                    "xlsx",
                    "xls",
                    "xlsm",
                    "xlsb",
                ]:
                    otherFiles.append(fileList)

        dataSel = widgets.Select(options=dataFiles, value=None, disabled=False)
        dataSel.observe(self.on_selFile, names="value")

        otherSel = widgets.Select(options=otherFiles, value=None, disabled=False)
        otherSel.observe(self.on_selFile, names="value")

        with self.dataOut:
            clear_output()
            display(widgets.VBox([widgets.Label("업로드한 데이터"), dataSel]))
        with self.otherOut:
            clear_output()
            display(widgets.VBox([widgets.Label("생성한 데이터"), otherSel]))

        display(self.aiduLayout)
        display(self.loadLayout)


class LearningCatalog:
    def __init__(self):
        self.tut_data_path = os.path.split(__file__)[0] + "/tutorial/"
        self.loadLayout = widgets.GridspecLayout(1, 10)  # ,height='1200px')
        self.loadLayout[0, :] = self.resultOut = widgets.Output()

    def on_loadTutorialData(self, btn):
        import pandas as pd
        import glob

        for name in glob.glob(self.tut_data_path + btn.description + "*"):
            self.df = pd.read_csv(name)
            self.fileName = btn.description
            self.metaData = ""
            ctx.newCatalog(self.fileName, self.metaData, self.df)
            with self.resultOut:
                clear_output()
                catalogName = makeCatalogName(self.fileName)
                display(
                    widgets.HBox(
                        [
                            widgets.Label("추가한 데이터 카탈로그 이름 : "),
                            widgets.Label(catalogName),
                        ]
                    )
                )
                display(widgets.Label("데이터 앞 부분 (Head)"))
                display(self.df.head())

    def getTutorialButtons(self):
        import glob
        from pathlib import Path

        btns = []
        for name in glob.glob(self.tut_data_path + "*"):
            btns.append((Path(name).stem, self.on_loadTutorialData))
        return btns

    def displayWidgets(self):
        display(uit.createHBoxButtons(self.getTutorialButtons()))
        display(self.loadLayout)


class EDAPBase(ABC):
    @property
    @abstractmethod
    def wgtParams(self):
        pass

    @property
    def query(self):
        return self.queryTmpl.format_map(self.params)

    @property
    @abstractmethod
    def queryTmpl(self):
        pass

    @abstractmethod
    def on_edapFetch(self):
        pass

    def on_changeParamValue(self, value):
        insertedParam = value["new"]
        if insertedParam.isnumeric():
            self.params[value["owner"].placeholder] = (
                insertedParam if int(insertedParam) < 1000000 else insertedParam
            )

    def displayEDAP(self):
        if ctx.conn is None:
            ctx.tryConnect()

        if ctx.checkEDAPConnect():
            self.on_edapFetch()
        else:
            display(widgets.Label(ctx.EDAPConnectStatus()))


class EDAPQuery(EDAPBase):
    def __init__(self):
        # design layouts
        self.layout = widgets.GridspecLayout(2, 10)
        self.layout[
            0, :5
        ] = (
            self.firstOut
        ) = widgets.Output()  # widgets.Output(layout=Layout(border='solid 2px'))
        self.layout[0, 5:] = self.secondOut = widgets.Output()
        self.layout[1, :5] = self.thirdOut = widgets.Output()
        self.layout[1, 5:] = self.fourthOut = widgets.Output()

    @property
    def wgtParams(self):
        wgtParams = []
        import re

        params = re.findall("{([a-zA-Z0-9]*)}", self.queryTmpl)
        self.params = {p: 0 for p in params}
        for item in self.params.keys():
            txt = widgets.Text(value=None, placeholder=item)
            txt.observe(self.on_changeParamValue, names="value")
            wgtParams.append(widgets.HBox([widgets.Label(item), txt]))
        return wgtParams

    def displayFirst(self):
        wgtTopics = widgets.Select(
            options=self.mainTopics,
            value=self.mainTopic,
            rows=10,
            description="",
            disabled=False,
        )
        wgtTopics.observe(self.onSelectMainTopic, names="value")
        with self.firstOut:
            clear_output()
            display(HTML("1. Choose a topic."))
            display(wgtTopics)

    def displaySecond(self):
        wgtQueries = widgets.Select(
            options=self.subTopics,
            value=self.subTopic,
            rows=10,
            description="",
            disabled=False,
        )
        wgtQueries.observe(self.onSelectQuery, names="value")
        # display
        with self.secondOut:
            clear_output()
            display(HTML("2. Choose a query**"))
            display(wgtQueries)

    def displayThird(self):
        with self.thirdOut:
            clear_output()
            display(HTML("3. Enter params"))
            # display(HTML(self.queryTmpl))
            display(widgets.VBox(self.wgtParams))
            display(self.btnExecQuery)

    def onSelectQuery(self, query):
        self.subTopic = query["new"]
        self.displayThird()
        self.fourthOut.clear_output()

    def on_execQuery(self, btn):
        # run query
        import pandas as pd

        queryResults = pd.read_sql(self.query, ctx.conn)
        with self.fourthOut:
            clear_output()
            # display(HTML('실행한 쿼리 : '+ self.query))
            ctx.newCatalog(self.subTopic, "", queryResults)
            display(
                widgets.HBox(
                    [widgets.Label("추가한 카탈로그 이름 : "), widgets.Label(self.subTopic)]
                )
            )
            display(queryResults.head())

    @property
    def queryTmpl(self):
        for row in self.topicResults:
            if row["sub_topic"] == self.subTopic:
                return str(row["query"])

    def onSelectMainTopic(self, topic):
        self.mainTopic = topic["new"]
        self.subTopic = self.subTopics[0]
        self.displaySecond()
        self.displayThird()
        self.fourthOut.clear_output()

    def on_edapFetch(self):
        topicCr = ctx.conn.cursor(dictify=True)
        topicCr.execute("""select * from aian.topic""")
        self.topicResults = topicCr.fetchall()
        self.mainTopics = list({row["main_topic"] for row in self.topicResults})
        self.mainTopic = self.mainTopics[0]
        self.subTopic = self.subTopics[0]
        self.btnExecQuery = widgets.Button(description="Run Query")
        self.btnExecQuery.on_click(self.on_execQuery)
        self.displayFirst()
        self.displaySecond()
        self.displayThird()
        self.fourthOut.clear_output()
        display(self.layout)

    @property
    def subTopics(self):
        return list(
            {
                row["sub_topic"]
                for row in self.topicResults
                if row["main_topic"] == self.mainTopic
            }
        )


class EDAPDB(EDAPBase):
    def __init__(self):
        # design layouts
        self.firstLayout = widgets.GridspecLayout(1, 10)
        self.firstLayout[
            0, :5
        ] = (
            self.firstOut
        ) = widgets.Output()  # widgets.Output(layout=Layout(border='solid 2px'))
        self.firstLayout[0, 5:] = self.secondOut = widgets.Output()
        self.secondLayout = widgets.GridspecLayout(1, 10)
        self.secondLayout[0, :5] = self.thirdOut = widgets.Output()
        self.secondLayout[0, 5:] = self.fourthOut = widgets.Output()
        self.fifthOut = widgets.Output()

    @property
    def wgtParams(self):
        wgtParams = []
        import re

        params = re.findall("{([a-zA-Z0-9]*)}", self.queryTmpl)
        self.params = {p: "1000" for p in params}
        for item in self.params.keys():
            txt = widgets.Text(value="1000", placeholder=item)
            txt.observe(self.on_changeParamValue, names="value")
            wgtParams.append(widgets.HBox([widgets.Label(item), txt]))
        return wgtParams

    def displayFirst(self):
        wgtDBs = widgets.Select(
            options=self.databases,
            value=self.currDatabase,
            rows=10,
            description="",
            disabled=False,
        )
        wgtDBs.observe(self.onSelectDB, names="value")
        with self.firstOut:
            clear_output()
            display(HTML("1. Choose a DB."))
            display(wgtDBs)

    def displaySecond(self):
        wgtTables = widgets.Select(
            options=self.currTables,
            value=self.currTable,
            rows=10,
            description="",
            disabled=False,
        )
        wgtTables.observe(self.onSelectTable, names="value")
        with self.secondOut:
            clear_output()
            display(HTML("2. Choose a table"))
            display(wgtTables)

    def displayThird(self):
        with self.thirdOut:
            clear_output()
            if self.currTable:
                from aiya.utils.uploadutils import makeBacktickName

                databaseName = makeBacktickName(self.currDatabase)
                tableName = makeBacktickName(self.currTable)
                infoQuery = "DESC " + databaseName + "." + tableName
                display(HTML("3. Table Info"))
                queryResults = pd.read_sql(infoQuery, ctx.conn)
                display(queryResults)

    def displayfourth(self):
        with self.fourthOut:
            clear_output()
            if self.currTable:
                display(HTML("4. Enter params"))
                # display(HTML(self.queryTmpl))
                display(widgets.VBox(self.wgtParams))
                display(self.btnExecQuery)

    def getTables(self):
        self.dbCr.execute("""show tables in """ + self.currDatabase)
        return [tabName["tab_name"] for tabName in self.dbCr.fetchall()]

    @property
    def queryTmpl(self):
        from aiya.utils.uploadutils import makeBacktickName

        databaseName = makeBacktickName(self.currDatabase)
        tableName = makeBacktickName(self.currTable)
        return "SELECT * FROM " + databaseName + "." + tableName + """  limit {limit}"""

    def on_execQuery(self, btn):
        # run query
        import pandas as pd

        queryResults = pd.read_sql(self.query, ctx.conn)
        with self.fifthOut:
            clear_output()
            # display(HTML('실행한 쿼리 : '+ self.query))
            ctx.newCatalog(self.currTable, "", queryResults)
            display(
                widgets.HBox(
                    [widgets.Label("추가한 카탈로그 이름 : "), widgets.Label(self.currTable)]
                )
            )
            display(queryResults.head())

    def onSelectTable(self, table):
        self.currTable = table["new"]
        self.displayThird()
        self.displayfourth()
        self.fifthOut.clear_output()

    def onSelectDB(self, table):
        self.currDatabase = table["new"]
        self.currTables = self.getTables()
        self.currTable = self.currTables[0] if self.currTables else None
        self.displaySecond()
        self.displayThird()
        self.displayfourth()
        self.fifthOut.clear_output()

    def on_edapFetch(self):
        self.dbCr = ctx.conn.cursor(dictify=True)
        self.dbCr.execute("""show databases""")
        self.databases = [dbName["database_name"] for dbName in self.dbCr.fetchall()]
        self.currDatabase = self.databases[0]
        self.currTables = self.getTables()
        self.currTable = self.currTables[0] if self.currTables else None
        self.btnExecQuery = widgets.Button(description="Run Query")
        self.btnExecQuery.on_click(self.on_execQuery)
        self.displayFirst()
        self.displaySecond()
        self.displayThird()
        self.displayfourth()
        self.fifthOut.clear_output()
        display(self.firstLayout)
        display(self.secondLayout)
        display(self.fifthOut)


PC = PCCatalog()
Learning = LearningCatalog()
EDAPQ = EDAPQuery()
EDAPD = EDAPDB()
AIdu = AIduCatalog()


def menu():
    def addMenuFunc(menuFunc, title):
        catalogAcc.set_title(len(menuFuncs), title)
        menuFuncs.append(menuFunc)

    def on_select(accordian):
        accIdx = accordian["new"]
        if accIdx is not None:
            with outList[accIdx]:
                clear_output()
                menuFuncs[accIdx]()

    clear_output()
    display(HTML("<h3>" + "데이터 카탈로그" + "</h3>"))
    catalogAcc = widgets.Accordion(selected_index=None)

    menuFuncs = []
    addMenuFunc(PC.displayWidgets, "PC에서 업로드")

    if ctx.checkEDAPAccount():
        addMenuFunc(EDAPD.displayEDAP, "EDAP에서 업로드 (DB)")
        addMenuFunc(EDAPQ.displayEDAP, "EDAP에서 업로드 (미리 정의된 쿼리)")

    from aiya.utils.uploadutils import checkAIdu

    if checkAIdu():
        addMenuFunc(AIdu.displayWidgets, "AIDU 데이터")

    addMenuFunc(Learning.displayWidgets, "학습용 데이터")

    outList = [widgets.Output() for menuFunc in menuFuncs]
    catalogAcc.children = outList
    catalogAcc.observe(on_select, names="selected_index")
    display(catalogAcc)
