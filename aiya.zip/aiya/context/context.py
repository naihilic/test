from aiya.constants import (
    AIAN_EDAP_USER_ID,
    AIAN_EDAP_USER_PW,
    ID_EXCEPTION,
    CONNECTION_EXCEPTION,
    AIAN_GPUS,
)
import aiya


class Context:
    def __init__(self):
        import os
        import matplotlib.font_manager as fm

        self._currProjectName = None
        self._projects = {}
        self.newProject("default")
        self._currStorageName = None
        self._storages = {}
        font_path = os.path.join(
            os.path.dirname(aiya.__file__), "resources", "NanumSquareRoundR.ttf"
        )
        fm.fontManager.addfont(path=font_path)
        self._fontProp = fm.FontProperties(fname=font_path)
        ## EDAP connect with os environ variable
        self.conn = self.userID = self.userPW = None
        if os.environ.get(AIAN_EDAP_USER_ID) and os.environ.get(AIAN_EDAP_USER_PW):
            self.userID = os.environ.get(AIAN_EDAP_USER_ID)
            self.userPW = os.environ.get(AIAN_EDAP_USER_PW)
        ## GPU variable
        self.gpus = self.getOSGPU()

    def checkEDAPAccount(self):
        check = False
        if self.userID or self.userPW:
            check = True
        return check

    def checkEDAPConnect(self):
        from impala.hiveserver2 import HiveServer2Connection

        check = False
        if type(self.conn) == HiveServer2Connection:
            check = True
        return check

    def EDAPConnectStatus(self):
        from impala.hiveserver2 import HiveServer2Connection

        if type(self.conn) == HiveServer2Connection:
            return " EDAP 계정이 올바르게 설정되었습니다. "
        elif self.conn == CONNECTION_EXCEPTION:
            return " EDAP 연결이 올바르지 않습니다. 방화벽이나 네트워크 연결을 확인하여 주시기 바랍니다."
        elif self.conn == ID_EXCEPTION:
            return " EDAP 계정이 올바르지 않습니다. 다시 설정해 주시기 바랍니다."
        elif self.conn == None:
            return " EDAP 계정이 설정되지 않았습니다. 설정해 주시기 바랍니다."
        else:
            return "EDAP 연결에 예외가 발생하였습니다."

    def getOSGPU(self):
        import os

        OSGPU = None
        if os.environ.get(AIAN_GPUS):
            OSGPU = os.environ.get(AIAN_GPUS).split()

        return OSGPU

    def tryConnect(self):
        from impala.dbapi import connect
        from thriftpy.transport import TTransportException as idException
        from thriftpy2.transport import TTransportException as connException

        try:
            self.conn = connect(
                host="10.220.232.209",
                port=10000,
                auth_mechanism="LDAP",
                user=self.userID,
                password=self.userPW,
            )
            # self.conn = connect(host='10.220.232.200', port=10000, auth_mechanism='LDAP', user=self.userID, password=self.userPW)
        # User Identification exception
        except idException:
            self.conn = ID_EXCEPTION
        except connException:
            self.conn = CONNECTION_EXCEPTION

    def newProject(self, projectName):
        self._currProjectName = projectName
        self._projects[projectName] = Project()

    def newCatalog(self, fileName, metaData, content):
        from aiya.utils.uploadutils import makeCatalogName

        catalogName = makeCatalogName(fileName)
        self.currProject._currCatalogName = catalogName
        self.currProject._catalogs[catalogName] = Catalog(fileName, metaData, content)

    def changeCurrProject(self, projectName):
        self._currProjectName = projectName

    def changeCurrCatalog(self, catalogName):
        self.currProject._currCatalogName = catalogName

    def changeCurrCatalogType(self, catalogType):
        self.currProject._catalogType = catalogType

    def removeCurrProject(self):
        del self._projects[self._currProjectName]
        self._currProjectName = "default"
        projectNames = self.projectNames
        if len(projectNames) <= 0:
            self.newProject("default")

    @property
    def currProject(self):
        return self._projects[self._currProjectName]

    @property
    def projectNames(self):
        return self._projects.keys()

    @property
    def currProjectName(self):
        return self._currProjectName

    def addProject(self, projectName, projectDef):
        self._projects[projectName] = projectDef

    ######### Low Level Wrapping ########
    @property
    def content(self):
        if self.currCatalog:
            return self.currCatalog._content
        else:
            return None

    def getCatalogByName(self, name):
        return self.currProject._catalogs[name]._content

    @property
    def currCatalog(self):
        if self.currProject._currCatalogName:
            return self.currProject._catalogs[self.currProject._currCatalogName]
        else:
            return None

    @property
    def catalogNames(self):
        return self.currProject._catalogs.keys()

    @property
    def currCatalogName(self):
        return self.currProject._currCatalogName

    @property
    def catalogType(self):
        return self.currProject._catalogType

    @property
    def fontName(self):
        return self._fontProp.get_name()

    ################################################################################


class Project:
    def __init__(self):
        self._currCatalogName = None
        self._catalogs = {}
        self._catalogType = "Tabular"


class Catalog:
    def __init__(self, fileName, metaData, content):
        self.fileName = fileName
        self._metaData = metaData
        self._content = content


class Storage:
    def __init__(self):
        self._currStorageName = None


if __name__ == "__main__":
    context = Context()
    print(context.currProject.name)
#####################  Using module variable(singleton)  #####################
context = Context()
