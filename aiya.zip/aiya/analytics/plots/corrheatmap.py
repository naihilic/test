from IPython.display import display, HTML
from ipywidgets import widgets, interact_manual, Label, SelectMultiple, Select, HBox

# from aiya.ui import tools
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from aiya.analytics.plots.baseplot import BasePlot


class CorrHeatMap(BasePlot):
    def __init__(self):
        super().__init__()
        self.selM = SelectMultiple(
            options=self.numColumns, value=self.colM, disabled=False, rows=self.rows
        )
        self.selM.observe(self.on_selM, names="value")

    def main(self):
        display(HTML("<h3>Correlation Heatmap - 항목들을 선택해주세요. </h3>"))
        display(HBox([Label("Columns:"), self.selM]))

        @interact_manual(nRows=(1, self.df.shape[0]))
        def drawf(nRows):
            if self.colM:
                df = self.df[self.colM]
                corr = df.iloc[:nRows].corr()
                # Generate a mask for the upper triangle
                mask = np.zeros_like(corr, dtype=np.bool)
                mask[np.triu_indices_from(mask)] = True
                # Set up the matplotlib figure
                f, ax = plt.subplots(figsize=(11, 9))
                # Generate a custom diverging colormap
                cmap = sns.diverging_palette(220, 10, as_cmap=True)
                # Draw the heatmap with the mask and correct aspect ratio
                sns.heatmap(
                    corr,
                    mask=mask,
                    cmap=cmap,
                    vmax=0.3,
                    center=0,
                    square=True,
                    linewidths=0.5,
                    cbar_kws={"shrink": 0.5},
                )
            else:
                display("Choose at least one column")
            return nRows
