from IPython.display import display, HTML
from ipywidgets import (
    widgets,
    interact_manual,
    Label,
    SelectMultiple,
    Select,
    HBox,
    VBox,
)

# from aiya.ui import tools
from aiya.analytics.plots.baseplot import BasePlot
import seaborn as sns
import matplotlib.pyplot as plt

######## All Type ########
class BoxPlot(BasePlot):
    def __init__(self):
        super().__init__()
        self.selY = Select(
            options=self.numColumns, value=self.colY, disabled=False, rows=self.rows
        )
        self.selX = Select(
            options=self.allColumns, value=self.colX, disabled=False, rows=self.rows
        )
        self.selX.observe(self.on_selX, names="value")
        self.selY.observe(self.on_selY, names="value")

    def main(self):
        display(HTML("<h3>Boxplot - 항목을 선택해주세요.</h3>"))
        display(
            HBox(
                [
                    VBox([Label("X:"), self.selX]),
                    VBox([Label("Y:"), self.selY]),
                    VBox([Label("Hue:"), self.selHue]),
                ]
            )
        )

        @interact_manual(nRows=(1, self.df.shape[0]))
        def drawf(nRows):
            if self.colX or self.colY:
                df = self.df.iloc[:nRows]
                plt.figure(figsize=(16, 6))
                sns.boxplot(
                    x=self.colX,
                    y=self.colY,
                    hue=self.colHue,
                    palette=["m", "g"],
                    data=df,
                )
                sns.despine(offset=10, trim=True)
            else:
                display("Choose at least one column")
            return nRows
