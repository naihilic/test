from IPython.display import display, HTML
from ipywidgets import (
    widgets,
    interact_manual,
    Label,
    SelectMultiple,
    Select,
    HBox,
    VBox,
)
import seaborn as sns
from aiya.analytics.plots.baseplot import BasePlot

######## Numeric Type ########
class PairPlot(BasePlot):
    def __init__(self):
        super().__init__()
        self.selM = SelectMultiple(
            options=self.numColumns, value=self.colM, disabled=False, rows=self.rows
        )
        self.selM.observe(self.on_selM, names="value")

    def main(self):
        display(HTML("<h3>Pairplot - 항목들을 선택해주세요. </h3>"))
        display(
            HBox(
                [
                    VBox([Label("Columns:"), self.selM]),
                    VBox([Label("Hue:"), self.selHue]),
                ]
            )
        )

        @interact_manual(nRows=(1, self.df.shape[0]))
        def drawf(nRows):
            if self.colM:
                df = self.df.iloc[:nRows]
                sns.pairplot(df, hue=self.colHue, vars=self.colM, diag_kind="hist")
            else:
                display("Choose at least one column")
            return nRows
