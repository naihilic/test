from ipywidgets import widgets, interact_manual, Label, SelectMultiple, Select, HBox
from IPython.display import display, HTML, Pretty
from aiya.context.context import context as ctx


class BasePlot:
    def __init__(self):
        self.colX = None
        self.colY = None
        self.colHue = None
        self.colM = []
        self.df = ctx.content
        self.rows = 10
        self.selM = SelectMultiple(
            options=self.allColumns, value=self.colM, disabled=False, rows=self.rows
        )
        self.selY = Select(
            options=self.allColumns, value=self.colY, disabled=False, rows=self.rows
        )
        self.selX = Select(
            options=self.allColumns, value=self.colX, disabled=False, rows=self.rows
        )
        self.selHue = Select(
            options=self.allColumns, value=self.colHue, disabled=False, rows=self.rows
        )
        self.selHue.observe(self.on_selHue, names="value")
        self.selX.observe(self.on_selX, names="value")
        self.selY.observe(self.on_selY, names="value")
        self.selM.observe(self.on_selM, names="value")

    @property
    def numColumns(self):
        columns = []
        columns.extend(self.df.select_dtypes(include=["number"]).columns)
        return columns

    @property
    def oColumns(self):
        columns = []
        columns.extend(self.df.select_dtypes(include=["object", "category"]).columns)
        return columns

    @property
    def allColumns(self):
        columns = []
        columns.extend(list(self.df.columns))
        return columns

    def on_selX(self, change):
        self.colX = change["new"]

    def on_selY(self, change):
        self.colY = change["new"]

    def on_selHue(self, change):
        self.colHue = change["new"]

    def on_selM(self, change):
        self.colM = list(change["new"])

    def main(self):
        display(HTML("<h3>Descriptions - Select columns </h3>"))
        display(HBox([Label("Columns:"), self.selM]))

        @interact_manual(nRows=(1, self.df.shape[0]))
        def drawf(nRows):
            if self.colM:
                df = self.df[:nRows][self.colM]
                display(HTML("1. Data"))
                display(df)
                display(HTML("2. Describe"))
                display(df.describe())
                display(HTML("3. Info"))
                Pretty(df.info())

            else:
                display(HTML("Choose at least one column"))
            return
