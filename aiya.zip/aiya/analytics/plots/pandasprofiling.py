from aiya.analytics.plots.baseplot import BasePlot


class PandasProfiling(BasePlot):
    def __init__(self):
        super().__init__()

    def main(self):
        from ipywidgets import (
            widgets,
            interact_manual,
            Label,
            SelectMultiple,
            Select,
            HBox,
        )
        from IPython.display import display, HTML, Pretty
        from pandas_profiling import ProfileReport
        from aiya.context.context import context as ctx

        display(HTML("<h3>Pandas-Profiling - Select columns </h3>"))
        display(HBox([Label("Columns:"), self.selM]))

        @interact_manual(nRows=(1, self.df.shape[0]))
        def drawf(nRows):
            if self.colM:
                df = self.df[:nRows][self.colM]
                profile = ProfileReport(df, title=ctx.currCatalogName)
                # profile.to_widgets()
                profile.to_notebook_iframe()
            else:
                display(HTML("Choose at least one column"))
            return
