from IPython.display import display, HTML
from ipywidgets import (
    widgets,
    interact_manual,
    Label,
    SelectMultiple,
    Select,
    HBox,
    VBox,
)

# from aiya.ui import tools
# import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from aiya.analytics.plots.baseplot import BasePlot

######## All Type ########
class ViolinPlot(BasePlot):
    def __init__(self):
        super().__init__()
        self.selM = SelectMultiple(
            options=self.numColumns, value=self.colM, disabled=False, rows=self.rows
        )
        self.selM.observe(self.on_selM, names="value")

    def main(self):
        display(HTML("<h3>Violinplot - 항목들을 선택해주세요. </h3>"))
        display(VBox([Label("Columns:"), self.selM]))

        @interact_manual(nRows=(1, self.df.shape[0]))
        def drawf(nRows):
            if self.colM:
                # df = self.df.iloc[:nRows]
                df = self.df[self.colM][:nRows]
                # data = df[colsChosen][:nRows]
                df = (df - df.mean()) / df.std().apply(lambda x: 1 if x == 0 else x)
                plt.figure(figsize=(20, 10))
                sns.violinplot(data=df)
                return nRows
            else:
                display("선택된 항목이 없습니다.")
