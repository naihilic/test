from IPython.display import display, HTML, clear_output
from ipywidgets import (
    widgets,
    interact_manual,
    Label,
    SelectMultiple,
    Select,
    HBox,
    VBox,
    Output,
)
from aiya.ui.tools import display_side_by_side
from aiya.ui.layout import *
import plotly.express as px
import pandas as pd
import numpy as np
import plotly.graph_objs as go
from sklearn.manifold import TSNE
from aiya.context.context import context as ctx
from aiya.utils.datautils import fillnaNumeric


class TSNEPlot:
    def __init__(self):
        self.rows = 12
        self.df = ctx.content
        self.columns = self.df.columns
        self.num_columns = self.df.select_dtypes(include=["number"]).columns
        self.selC = SelectMultiple(
            options=self.num_columns,
            value=[self.columns[0]],
            disabled=False,
            rows=self.rows,
        )
        self.selH = Select(
            options=self.columns,
            value=self.num_columns[0],
            disabled=False,
            rows=self.rows,
        )
        self.selH.observe(self.on_selH, names="value")
        self.outH = Output()
        self.intTable = Output()

    def on_selH(self, change):
        if type(change) is str:
            df_hue = self.df[[change]].copy()
        else:
            df_hue = self.df[[change["new"]]].copy()
        data_hue = df_hue[:8]
        data_hue.columns = ["Data head"]
        des_hue = df_hue.describe()
        des_hue.columns = ["Data describe"]
        with self.outH:
            clear_output()
            display_side_by_side(data_hue, des_hue)

    def on_scatter_selection(self, t, p, s):
        t_row = p.point_inds
        t_df = self.df.loc[t_row,].copy()
        with self.intTable:
            clear_output()
            pd.set_option("display.max_rows", None)
            display(t_df)
            pd.reset_option("display.max_rows")

    def main(self):
        title = HTML(
            "<h3>T-Distributed Stochastic Neighbor Embedding - 항목들을 선택해주세요. </h3>"
        )

        sel_column = VBox([Label("Columns:"), self.selC])
        sel_hue = VBox([Label("Hue"), self.selH])
        self.on_selH(self.selH.value)

        col_hue = HBox([sel_column, sel_hue, self.outH])

        # display area
        display(title)
        display(col_hue)

        @interact_manual(nRows=(1, self.df.shape[0]), perplexity=(1, 100))
        def drawf(nRows, perplexity):
            tsne_df = self.df[list(self.selC.value)][:nRows].copy()
            tsne_df = fillnaNumeric(tsne_df)
            hue = self.df[self.selH.value][:nRows]
            # if hue is numeric...git c
            if hue.dtype in ["int64", "float64"]:  # hue column is numeric
                hue = (hue - hue.mean()) / hue.std()
                hue = 100 / (1 + np.exp(-1 * hue * 10)) // 1
            else:
                hue.fillna("unknown", inplace=True)
            hue_df = pd.DataFrame(hue).rename(
                columns={self.selH.value: self.selH.value + "(hue)"}
            )

            tsne = TSNE(n_components=2, verbose=1, perplexity=perplexity, n_iter=1000)
            tsne_out = tsne.fit_transform(tsne_df)
            tsne_df["one"] = tsne_out[:, 0]
            tsne_df["two"] = tsne_out[:, 1]

            plot_df = pd.concat([tsne_df, hue_df], axis=1)

            # drawing plot scatter
            fig = px.scatter(plot_df, x="one", y="two", color=self.selH.value + "(hue)")
            fig.update_layout(layout_tsne)

            go_fig = go.FigureWidget(fig)
            scatter = go_fig.data[0]
            scatter.on_selection(self.on_scatter_selection)

            display(go_fig)

        display(self.intTable)
