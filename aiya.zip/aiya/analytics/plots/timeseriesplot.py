from IPython.display import display, HTML
from ipywidgets import (
    widgets,
    interact_manual,
    Label,
    SelectMultiple,
    Select,
    HBox,
    VBox,
)

# from aiya.ui import tools
import pandas as pd
import seaborn as sns
from aiya.analytics.plots.baseplot import BasePlot


class TimePlot(BasePlot):
    def __init__(self):
        super().__init__()
        self.selM = SelectMultiple(
            options=self.numColumns, value=self.colM, disabled=False, rows=self.rows
        )
        self.selM.observe(self.on_selM, names="value")

    def main(self):
        display(HTML("<h3>Timeseries plot - 항목을 선택해주세요. </h3>"))
        display(
            HBox(
                [
                    VBox([Label("Time(단수항목) :"), self.selX]),
                    VBox([Label("Data(복수항목):"), self.selM]),
                ]
            )
        )

        @interact_manual(nRows=(1, self.df.shape[0]))
        def drawf(nRows):
            import matplotlib.pyplot as plt

            # added code by warning
            from pandas.plotting import register_matplotlib_converters

            register_matplotlib_converters()
            df = self.df
            if self.colM:
                try:
                    df = df.sort_values(by=[self.colX], axis=0)  # order by time
                    # convert X to datetime format
                    X = (
                        pd.to_datetime(df[self.colX][:nRows].values)
                        if df[self.colX].dtype in ["object"]
                        else df[self.colX][:nRows].values
                    )
                except:
                    # when X couldn't be converted to datetime format, set index to x-axis
                    display("시간으로 변환 할 수 없는 항목입니다.")
                    X = range(nRows)
                Y = df[self.colM][:nRows].values  # values of y-axis

                plt.figure(figsize=(16, 6))
                plt.plot(X, Y, "-")
                plt.legend(self.colM)
            else:
                display("선택된 항목이 없습니다.")
            return nRows
