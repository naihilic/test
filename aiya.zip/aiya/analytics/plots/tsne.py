from IPython.display import display, HTML
from ipywidgets import (
    widgets,
    interact_manual,
    Label,
    SelectMultiple,
    Select,
    HBox,
    VBox,
)

# from aiya.ui import tools
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from aiya.analytics.plots.baseplot import BasePlot
from aiya.utils.datautils import fillnaNumeric


class TSNEPlot(BasePlot):
    def __init__(self):
        super().__init__()
        self.selM = SelectMultiple(
            options=self.numColumns, value=self.colM, disabled=False, rows=self.rows
        )
        self.selM.observe(self.on_selM, names="value")

    def main(self):
        display(
            HTML("<h3>T-Distributed Stochastic Neighbor Embedding - 항목들을 선택해주세요. </h3>")
        )
        ## display component
        display(
            HBox(
                [
                    VBox([Label("Columns:"), self.selM]),
                    VBox([Label("Hue:"), self.selHue]),
                ]
            )
        )

        @interact_manual(nRows=(1, self.df.shape[0]), perplexity=(1, 100))
        def drawf(nRows, perplexity):
            if self.colM:
                tsneDf = self.df[self.colM][:nRows].copy()
                tsneDf = fillnaNumeric(tsneDf)
                ncolors = None
                hue = None
                if self.colHue is not None:
                    hue = self.df[self.colHue][:nRows]
                    ## if hue is numeric...
                    if hue.dtype in ["int64", "float64"]:  # hue column is numeric
                        hue = (hue - hue.mean()) / hue.std()
                        hue = 30 / (1 + np.exp(-1 * hue * 10)) // 1
                    ncolors = hue.unique().shape[0]
                # tsne

                tsne = TSNE(
                    n_components=2, verbose=1, perplexity=perplexity, n_iter=1000
                )
                tsne_out = tsne.fit_transform(tsneDf)
                tsneDf["tsne-2d-one"] = tsne_out[:, 0]
                tsneDf["tsne-2d-two"] = tsne_out[:, 1]
                # plot
                plt.figure(figsize=(20, 10))
                sns.scatterplot(
                    x="tsne-2d-one",
                    y="tsne-2d-two",
                    hue=hue,
                    palette=sns.color_palette("hsv", ncolors),
                    data=tsneDf,
                    # legend="full",
                    alpha=0.3,
                )
            else:
                display("선택된 항목이 없습니다.")
            return (nRows, perplexity)
