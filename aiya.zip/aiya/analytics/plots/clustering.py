from IPython.display import display, HTML
from ipywidgets import (
    widgets,
    interact_manual,
    Label,
    SelectMultiple,
    Select,
    HBox,
    VBox,
)
from aiya.ui import tools
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
from plotly.offline import iplot
from plotly.offline import init_notebook_mode
from aiya.analytics.plots.baseplot import BasePlot
from functools import reduce
import plotly.express as px
from aiya.utils.datautils import fillnaNumeric


class Clustering(BasePlot):
    def __init__(self):
        super().__init__()
        self.clsMethod = "K-means"
        self.selM = SelectMultiple(
            options=self.numColumns, value=self.colM, disabled=False, rows=self.rows
        )
        self.selM.observe(self.on_selM, names="value")
        self.selCls = Select(
            options=["K-means", "hierarchy"],
            value=self.clsMethod,
            disabled=False,
            rows=self.rows,
        )
        self.selCls.observe(self.on_selCls, names="value")

    def on_selCls(self, change):
        self.clsMehtod = change["new"]

    def main(self):
        display(HTML("<h3>Clustering - 항목들을 선택해주세요.</h3>"))
        display(
            HBox(
                [
                    VBox([Label("Columns:"), self.selM]),
                    VBox([Label("Clustering Method:"), self.selCls]),
                ]
            )
        )

        @interact_manual(
            nRows=(1, self.df.shape[0]), numCls=(1, 10), Reduction=["PCA", "TSNE"]
        )
        def drawf(nRows, numCls, Reduction):
            if self.colM:
                clusterDf = self.df[self.colM][:nRows]
                # clusterDf = clusterDf.fillna(clusterDf.mean())
                clusterDf = fillnaNumeric(clusterDf)
                clusterDf = (clusterDf - clusterDf.mean()) / clusterDf.std().apply(
                    lambda x: 1 if x == 0 else x
                )
                if self.clsMethod == "K-means":
                    from sklearn.cluster import KMeans

                    model = KMeans(n_clusters=numCls, algorithm="auto")
                elif self.clsMethod == "hierarchy":
                    from sklearn.cluster import AgglomerativeClustering

                    model = AgglomerativeClustering(n_clusters=numCls, linkage="ward")
                cluster = pd.DataFrame(
                    model.fit_predict(clusterDf), columns=["cluster"]
                )
                trans_data = pd.DataFrame()
                if Reduction == "PCA":
                    if len(self.colM) >= 3:
                        pca = PCA(n_components=3)
                        pca_out = pca.fit_transform(clusterDf)
                        trans_data["one-dim"] = pca_out[:, 0]
                        trans_data["two-dim"] = pca_out[:, 1]
                        trans_data["three-dim"] = pca_out[:, 2]
                    else:
                        display(HTML("3개 이상의 항목을 선택하세요"))
                        return
                elif Reduction == "TSNE":
                    tsne = TSNE(n_components=3, verbose=1, perplexity=50, n_iter=1000)
                    tsne_out = tsne.fit_transform(clusterDf)
                    trans_data["one-dim"] = tsne_out[:, 0]
                    trans_data["two-dim"] = tsne_out[:, 1]
                    trans_data["three-dim"] = tsne_out[:, 2]
                init_notebook_mode(connected=True)
                fig = px.scatter_3d(
                    trans_data, x="one-dim", y="two-dim", z="three-dim", color=cluster
                )
                iplot(fig)
            else:
                display("선택된 항목이 없습니다.")
