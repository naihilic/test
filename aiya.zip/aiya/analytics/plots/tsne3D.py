from IPython.display import display, HTML
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
from plotly.offline import iplot, plot
import plotly.graph_objs as go
from plotly.offline import init_notebook_mode
from ipywidgets import (
    widgets,
    interact_manual,
    Label,
    SelectMultiple,
    Select,
    HBox,
    VBox,
)
from aiya.ui import tools
import pandas as pd
import numpy as np
import seaborn as sns
import plotly.express as px
from aiya.utils.datautils import fillnaNumeric
from aiya.analytics.plots.tsne import TSNEPlot


class TSNE3DPlot(TSNEPlot):
    def __init__(self):
        super().__init__()
        self.selM = SelectMultiple(
            options=self.numColumns, value=self.colM, disabled=False, rows=self.rows
        )
        self.selM.observe(self.on_selM, names="value")

    def main(self):
        display(
            HTML(
                "<h2>3D T-distributed stochastic neighbor embedding - 항목들을 선택해주세요. </h3>"
            )
        )
        ## display component
        display(
            HBox(
                [
                    VBox([Label("Columns:"), self.selM]),
                    VBox([Label("Hue:"), self.selHue]),
                ]
            )
        )
        ## TODO: select hue column
        @interact_manual(nRows=(1, self.df.shape[0]), perplexity=(1, 100))
        def drawf(nRows, perplexity):
            if self.colM:
                tsneDf = self.df[self.colM][:nRows].copy()
                tsneDf = fillnaNumeric(tsneDf)
                hue = None
                if self.colHue is not None:
                    hue = self.df[self.colHue][:nRows]
                    ## if hue is numeric...
                    if hue.dtype in ["int64", "float64"]:  # hue column is numeric
                        hue = (hue - hue.mean()) / hue.std()
                        hue = 30 / (1 + np.exp(-1 * hue * 10)) // 1
                # tsne

                tsne = TSNE(
                    n_components=3, verbose=1, perplexity=perplexity, n_iter=1000
                )
                tsne_out = tsne.fit_transform(tsneDf)
                tsneDf["tsne-3d-one"] = tsne_out[:, 0]
                tsneDf["tsne-3d-two"] = tsne_out[:, 1]
                tsneDf["tsne-3d-three"] = tsne_out[:, 2]
                # plot
                init_notebook_mode(connected=True)
                fig = px.scatter_3d(
                    tsneDf,
                    x="tsne-3d-one",
                    y="tsne-3d-two",
                    z="tsne-3d-three",
                    color=hue,
                    size_max=3,
                )
                iplot(fig)
            else:
                display("선택된 항목이 없습니다.")
