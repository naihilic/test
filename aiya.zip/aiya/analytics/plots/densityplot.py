from IPython.display import display, HTML
from ipywidgets import widgets, interact_manual, Label, SelectMultiple, Select, HBox

# from aiya.ui import tools
import pandas as pd
import seaborn as sns
from aiya.analytics.plots.baseplot import BasePlot


class DensityPlot(BasePlot):
    def __init__(self):
        super().__init__()
        self.selX = Select(
            options=self.numColumns, value=self.colX, disabled=False, rows=self.rows
        )
        self.selX.observe(self.on_selX, names="value")

    def main(self):
        display(HTML("<h3>Density plot - 항목을 선택해주세요. </h3>"))
        display(HBox([Label("Column:"), self.selX]))

        @interact_manual(nRows=(1, self.df.shape[0]))
        def drawf(nRows):
            import matplotlib.pyplot as plt

            # By warning
            from pandas.plotting import register_matplotlib_converters

            register_matplotlib_converters()
            if self.colX:
                series = self.df[self.colX][:nRows]  # values of y-axis
                plt.figure(figsize=(16, 6))
                sns.distplot(series.dropna())
            else:
                display("Choose one column")
            return nRows
