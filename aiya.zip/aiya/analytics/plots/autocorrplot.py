from IPython.display import display, HTML
from aiya.analytics.plots.baseplot import BasePlot


class AutoCorrPlot(BasePlot):
    def __init__(self):
        super().__init__()

    def main(self):
        from ipywidgets import (
            widgets,
            interact_manual,
            Label,
            SelectMultiple,
            Select,
            HBox,
            VBox,
        )

        # from aiya.ui import tools
        import pandas as pd
        import seaborn as sns

        display(HTML("<h3>Autocorrelation plot - 항목을 선택해주세요. </h3>"))
        # X : time-series data
        display(
            HBox(
                [VBox([Label("Time :"), self.selX]), VBox([Label("Data:"), self.selY])]
            )
        )

        @interact_manual(nRows=(1, self.df.shape[0]))
        def drawf(nRows):
            import matplotlib.pyplot as plt

            # added code by warning
            from pandas.plotting import register_matplotlib_converters

            register_matplotlib_converters()
            if self.colY:
                df = self.df
                try:
                    df = df.sort_values(by=[self.colX], axis=0)  # order by time
                    # convert X to datetime format
                    X = (
                        pd.to_datetime(df[self.colX][:nRows].values)
                        if df[self.colX].dtype in ["object"]
                        else df[self.colX][:nRows].values
                    )
                except:
                    # when X couldn't be converted to datetime format, set index to x-axis
                    display("시간으로 변환 할 수 없는 항목입니다.")
                    X = range(nRows)
                Y = df[self.colY][:nRows].values  # values of y-axis
                plt.figure(figsize=(16, 6))
                pd.plotting.autocorrelation_plot(Y)
            else:
                display("항목이 선택되지 않았습니다.")
            return nRows
