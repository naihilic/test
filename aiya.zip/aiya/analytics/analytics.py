from IPython.display import display, HTML, clear_output
from aiya.context.context import context as ctx


def on_changeProject(projectName):
    ctx.changeCurrProject(projectName["new"])
    menu()


def on_changeCatalog(catalogName):
    ctx.changeCurrCatalog(catalogName["new"])
    menu()


def on_changeCatalogType(catalogType):
    ctx.changeCurrCatalogType(catalogType["new"])
    menu()


def on_changeMethod(methodName):
    menu(method=methodName["new"])


def displayData(df, method="Description"):
    if df is None:
        display(HTML("Empty"))
    elif method == "Description":
        from aiya.analytics.plots.baseplot import BasePlot

        BasePlot().main()
    elif method == "Pandas-profiling":
        from aiya.analytics.plots.pandasprofiling import PandasProfiling

        PandasProfiling().main()
    elif method == "Pairplot":
        from aiya.analytics.plots.pairplot import PairPlot

        PairPlot().main()
    elif method == "CorrHeatmap":
        from aiya.analytics.plots.corrheatmap import CorrHeatMap

        CorrHeatMap().main()
    elif method == "Boxplot":
        from aiya.analytics.plots.boxplot import BoxPlot

        BoxPlot().main()
    elif method == "Violinplot":
        from aiya.analytics.plots.violinplot import ViolinPlot

        ViolinPlot().main()
    elif method == "t-SNE":
        from aiya.analytics.plots.tsne import TSNEPlot

        TSNEPlot().main()
    elif method == "t-SNE_3D":
        from aiya.analytics.plots.tsne3D import TSNE3DPlot

        TSNE3DPlot().main()
    elif method == "Clustering":
        from aiya.analytics.plots.clustering import Clustering

        Clustering().main()
    elif method == "Time-series plot":
        from aiya.analytics.plots.timeseriesplot import TimePlot

        TimePlot().main()
    elif method == "Autocorrelation":
        from aiya.analytics.plots.autocorrplot import AutoCorrPlot

        AutoCorrPlot().main()
    elif method == "Densityplot":
        from aiya.analytics.plots.densityplot import DensityPlot

        DensityPlot().main()
    elif method == "t-SNE_extended":
        from aiya.analytics.plots.tsne_ext import TSNEPlot

        TSNEPlot().main()


def menu(method="Description"):
    import ipywidgets as widgets
    from aiya.ui import tools as uit
    from aiya import constants
    import pandas as pd

    ## local constants
    """
    catalogTypes = {'Tabular': ['Description', 'Pairplot', 'CorrHeatmap', 'Boxplot', 'Violinplot', 't-SNE', 'Clustering', 'Foo'],
                    'TimeSeries': ['Description', 'Foo-Series'] ,
                    'Text': ['Description', 'Foo-TextCloud'] }
    """
    clear_output()
    analyMethod = constants.ANALYTIC_METHODS

    # Project
    ddProject = widgets.Dropdown(
        options=list(ctx.projectNames),
        value=ctx.currProjectName,
        description="",
        disabled=False,
    )
    ddProject.observe(on_changeProject, names="value")
    # Catalog
    # Catalog.1 Catalog Data
    ddCatalog = widgets.Dropdown(
        options=list(ctx.catalogNames),
        value=ctx.currCatalogName,
        description="",
        disabled=False,
    )
    ddCatalog.observe(on_changeCatalog, names="value")
    # Catalog.2 Catalog Type
    ddCatalogType = widgets.Dropdown(
        options=analyMethod.keys(),
        value=ctx.catalogType,
        description="",
        disabled=False,
    )
    ddCatalogType.observe(on_changeCatalogType, names="value")
    # Methods
    ddMethod = widgets.Dropdown(
        options=analyMethod[ctx.catalogType],
        value=method,  # if method in types else type[0]
        description="",
        disabled=False,
    )
    ddMethod.observe(on_changeMethod, names="value")
    # display if data is not empty
    display(HTML("<h3>" + "데이터 분석" + "</h3>"))
    # display(HTML('<hr>'))
    display(widgets.HBox([widgets.Label("* 현재 프로젝트: "), ddProject]))
    display(widgets.HBox([widgets.Label("* 현재 카탈로그: "), ddCatalog]))
    display(widgets.HBox([widgets.Label("* 분석 방법: "), ddCatalogType, ddMethod]))
    # display(HTML('<hr>'))
    displayData(ctx.content, method=method)
