# By naihil
c.NotebookApp.tornado_settings = {"websocket_max_message_size":
500*1024*1024}