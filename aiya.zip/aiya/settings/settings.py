import ipywidgets as widgets
from aiya.ui import tools as uit
from IPython.display import display, HTML,clear_output
from aiya.context.context import context as ctx
from aiya.constants import ID_EXCEPTION,CONNECTION_EXCEPTION
def edapAccount():
    def checkAccount():
        from impala.hiveserver2 import HiveServer2Connection
        if type(ctx.conn) == HiveServer2Connection: 
            resultLabel.value = ' EDAP 계정이 올바르게 설정되었습니다. '
        elif ctx.conn == CONNECTION_EXCEPTION:
            resultLabel.value = ' EDAP 연결이 올바르지 않습니다. 방화벽이나 네트워크 연결을 확인하여 주시기 바랍니다.'
        elif ctx.conn == ID_EXCEPTION:
            resultLabel.value = ' EDAP 계정이 올바르지 않습니다. 다시 설정해 주시기 바랍니다.'
        elif ctx.conn == None:
            resultLabel.value = ' EDAP 계정이 설정되지 않았습니다. 설정해 주시기 바랍니다.'
    def on_click(btn):
        ctx.userID = userID.value
        ctx.userPW = userPassword.value
        ctx.refreshConnect()
        checkAccount()
    userID = widgets.Text(value=ctx.userID)
    userPassword = widgets.Password(value = ctx.userPW)
    idBox = widgets.HBox([widgets.Label('EDAP ID : '),userID])
    pwdBox = widgets.HBox([widgets.Label('EDAP PW : '),userPassword])
    resultLabel = widgets.Label()
    btnSaveEnv = widgets.Button(description = '설정')
    btnSaveEnv.on_click(on_click)
    display(widgets.VBox([idBox,pwdBox,btnSaveEnv,resultLabel]))
    checkAccount()
def gpuSetting():
    def on_check(box):
        if GPUCheckbox.value:
            ctx.gpus = ctx.getOSGPU()
        else:
            ctx.gpus = None
    GPUS = ctx.getOSGPU()
    GPUWidgets = []

    if GPUS: 
        GPUTexts = [widgets.Text(value=GPUText,description='GPU '+ str(idx+1),disabled=True) for idx,GPUText in enumerate(GPUS)]
        GPUWidgets.extend(GPUTexts)
        GPUCheckbox = widgets.Checkbox(description = '사용', value = True if ctx.gpus else False)
        GPUCheckbox.observe(on_check,names='value')
        GPUWidgets.append(GPUCheckbox)
    else:
        GPUWidgets.append(widgets.Label(value='설정된 GPU가 없습니다.'))
    display(widgets.VBox(GPUWidgets))

    

        


def menu():
    def on_select(accordian):
        accIdx=accordian['new']
        if accIdx is not None:
            outputWidget = outList[accIdx]
            with outputWidget:
                clear_output()
                menuFuncs[accIdx]()
    clear_output()
    display(HTML('<h3>'+'설정'+'</h3>'))
    settingAcc = widgets.Accordion(selected_index=None)
    menuFuncs  = [edapAccount,gpuSetting]
    outList = [widgets.Output() for menufunc in menuFuncs]
    settingAcc.children = outList
    settingAcc.set_title(0,'EDAP 계정 설정')
    settingAcc.set_title(1,'GPU 설정')
    settingAcc.observe(on_select,names='selected_index')
    display(settingAcc)
    