"""
 Constant Management
"""
JSON_OPTION = ["split", "records", "index", "columns", "values"]
CSV_OPTION = [
    (", (comma)", ","),
    ("; (semicolon)", ";"),
    ("| (pipe)", "|"),
    ("\t (tab)", "\t"),
    ("  (space)", " "),
]
ANALYTIC_METHODS = {
    "Tabular": [
        "Description",
        "Pandas-profiling",
        "Pairplot",
        "CorrHeatmap",
        "Boxplot",
        "Violinplot",
        "t-SNE",
        "t-SNE_3D",
        "Densityplot",
        "Clustering",
        "t-SNE_extended",
    ],
    "Time-series": ["Description", "Time-series plot", "Autocorrelation"],
    "Text": ["Description",],
}
#'Proceeding':['Description','TextCloud'] }

LEARNING_MODELS = {
    "Tabular": ["Undefined", "Tabular_Vanilla"],
    "Time-series": ["Undefined", "Uni_variate"],
    "Text": ["Undefined", "Text_Vanilla"],
}
#'Proceeding':['Undefined','SentimentAnalysis','Image_Vanilla', 'anoGan', 'vae'] }
PROCESSING_METHODS = {
    "Tabular": ["Description"],
    "Time-series": ["Description"],
    "Text": ["Description", "NLP-Korean"],
}
#'Proceeding':['Description'] }
NORMALIZATION_METHODS = ["Standard", "Minmax", "Tanh", "Sigmoid"]
######## Ludwig Params ########
ID_EXCEPTION = "id exception"
CONNECTION_EXCEPTION = "connection exception"
AIAN_EDAP_USER_ID = "AIAN_EDAP_USER_ID"
AIAN_EDAP_USER_PW = "AIAN_EDAP_USER_PW"
AIAN_GPUS = "AIAN_GPUS"
INPUT_LUDWIG_PARAMS = {
    "date": {},
    "numerical": {},
    "binary": {},
    "category": {},
    "timeseries": {
        "encoder": "rnn",
        "cell_type": "rnn",
        "num_layers": 1,
        "state_size": 256,
    },
    "text": {"level": "word", "encoder": "parallel_cnn"},
    "text_ko": {"level": "word", "encoder": "parallel_cnn"},
}
OUTPUT_LUDWIG_PARAMS = {"numerical": {}, "binary": {}, "category": {}}
INPUT_CUSTOM_PARAMS = {
    "numerical": {},
    "binary": {},
    "category": {},
    "timeseries": {"sequenceLen": 1, "normMethod": "Standard"},
    "text": {},
    "text_ko": {},
}
OUTPUT_CUSTOM_PARAMS = {"numerical": {}, "binary": {}, "category": {}, "timeseries": {}}
STYLE = """
    <style>
       .jupyter-widgets-output-area .output_scroll {
            height: unset !important;
            border-radius: unset !important;
            -webkit-box-shadow: unset !important;
            box-shadow: unset !important;
        }
        .jupyter-widgets-output-area  {
            height: auto !important;
        }
    </style>
    """
