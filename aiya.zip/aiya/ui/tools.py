from ipywidgets import widgets
from IPython.display import display_html

"""
TODO: 
  Currently it will work only on where is set to below
  because of using cell-index value..
  it's to be modified 
"""


def createCellAndRun(script, where="below"):
    from IPython.display import display_javascript

    tmplScript = """
      var curr_cell = IPython.notebook.get_selected_cell()
      var curr_idx = IPython.notebook.get_cells().indexOf(curr_cell);
      //var next_cell = IPython.notebook.get_cell(curr_idx+1);
      var next_cell = IPython.notebook.insert_cell_{where}('');   
      next_cell.set_text('{script}')
      IPython.notebook.to_code(curr_idx+1);
      IPython.notebook.get_cell(curr_idx+1).render();
      IPython.notebook.execute_cells([curr_idx+1]);
"""
    return display_javascript(tmplScript.format(script=script, where=where), raw=True)


def createRefreshCellLink(linkScript, linkName):
    tmplScript = """
<script>
function fnLink() {{
  var curr_cell = IPython.notebook.get_selected_cell();
  curr_cell.set_text('{script}');
  IPython.notebook.execute_cell(curr_cell);
}}
</script>
<a href="#" onClick="fnLink()"> {name} </a>"""
    return tmplScript.format(script=linkScript, name=linkName)


def createNavigationBar(menuPath):
    # from aiya.context import context

    from aiya import constants

    outScript = """
<script>
function fnLink(script) {{
  var curr_cell = IPython.notebook.get_selected_cell();
  curr_cell.set_text(script);
  IPython.notebook.execute_cell(curr_cell);
}}</script>
메뉴경로
"""
    linkScriptTmpl = ' &gt <a href="#" onClick="fnLink(\'{script}\')"> {name}</a>'

    linkScripts = []
    menuItems = menuPath.split(".")
    menu = ""
    for idx, item in enumerate(menuItems):
        menu += item if idx <= 0 else "." + item
        linkScripts.append(constants.menu[menu])

    for linkScript in linkScripts:
        outScript += linkScriptTmpl.format(
            script=linkScript["script"], name=linkScript["name"]
        )
    outScript += "<h1>" + linkScripts[-1]["name"] + "</h1> <hr>"
    return outScript


def backToHome():
    return createRefreshCellLink("from aiya.home import home\\nhome.init()", "첫페이지로 가기")


def backToProject():
    return createRefreshCellLink(
        "from aiya.project import project\\nproject.menu()", "프로젝트로 가기"
    )


def createButton(desc, handler):
    if isinstance(desc, widgets.Button):
        btnNew = desc
    else:
        btnNew = widgets.Button(description=desc)
    btnNew.on_click(handler)
    return btnNew


def createHBoxButtons(btnSpecs):
    return widgets.HBox([createButton(desc, handler) for desc, handler in btnSpecs])


def createVBoxButtons(btnSpecs):
    return widgets.VBox([createButton(desc, handler) for desc, handler in btnSpecs])


def display_side_by_side(*args):
    html_str = ""
    for df in args:
        html_str += df.to_html()
    display_html(html_str.replace("table", 'table style="display:inline"'), raw=True)


def display_download(data, filename, title=None, data_type="application/csv"):
    if title is None:
        title = filename
    import base64

    b64 = base64.b64encode(data)
    payload = b64.decode()
    html = '<a download="{filename}" href="data:{data_type};base64,{payload}" target="_blank">{title}</a>'
    html = html.format(
        payload=payload, title=title, filename=filename, data_type=data_type
    )
    display_html(html, raw=True)
