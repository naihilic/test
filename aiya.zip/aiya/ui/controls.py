from ipywidgets import widgets
from aiya.context.context import context as ctx


def createButton(desc, handler):
    btnNew = widgets.Button(description=desc)
    btnNew.on_click(handler)
    return btnNew


def createHBoxButtons(btnSpecs):
    # btnSpecs = [('Describe', on_describe), ('Scatter', on_show_scatter), ('Heatmap', on_show_heatmap), ('BoxPlot', on_show_boxplot)]
    return widgets.HBox([createButton(desc, handler) for desc, handler in btnSpecs])


def createProjectCatalogSelection(method, btn, btn2):
    from IPython.display import display

    switch = True if ctx.currCatalogName is None else False

    def on_project_change(projectName):
        ctx.changeCurrProject(projectName["new"])
        ddCatalog.options = list(ctx.catalogNames)
        ddCatalog.value = ctx.currCatalogName
        ddCatalogType.value = ctx.catalogType

    def on_catalog_change(catalogName):
        ctx.changeCurrCatalog(catalogName["new"])

    def on_catalog_type_change(catalogType):
        ctx.changeCurrCatalogType(catalogType["new"])
        ddMethod.options = method[catalogType["new"]]

    def on_method_change(method):
        btn.value = method["new"]
        btn2.value = method["new"]

    ddProject = widgets.Dropdown(
        options=list(ctx.projectNames),
        value=ctx.currProjectName,
        description="",
        disabled=False,
    )

    ddCatalog = widgets.Dropdown(
        options=list(ctx.catalogNames),
        value=ctx.currCatalogName,
        description="",
        disabled=switch,
    )

    ddCatalogType = widgets.Dropdown(
        options=method.keys(), value=ctx.catalogType, description="", disabled=switch
    )

    ddMethod = widgets.Dropdown(options=method[ddCatalogType.value], disabled=switch)
    btn.disabled = switch
    btn2.disabled = switch

    ddProject.observe(on_project_change, names="value")
    ddCatalog.observe(on_catalog_change, names="value")
    ddCatalogType.observe(on_catalog_type_change, names="value")
    ddMethod.observe(on_method_change, names="value")

    btn.value = ddMethod.value
    btn2.value = ddMethod.value
    display(widgets.HBox([widgets.Label("* 현재 프로젝트: "), ddProject]))
    display(widgets.HBox([widgets.Label("* 현재 카탈로그: "), ddCatalog]))
    display(widgets.HBox([widgets.Label("* 카탈로그 분류: "), ddCatalogType]))
    display(widgets.HBox([widgets.Label("* 방법 선택　　: "), ddMethod, btn, btn2]))
