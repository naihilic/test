from ipywidgets import Layout

layout_tsne = dict(
    margin=dict(l=10, r=10, t=10, b=10),
    legend=dict(
        x=0,
        y=1,
        title="",
        font=dict(size=12, color="black"),
        bgcolor="LightSteelBlue",
        bordercolor="Black",
        borderwidth=2,
        orientation="h",
        itemsizing="constant",
    ),
    xaxis=dict(title=None, showgrid=False, zeroline=False, showticklabels=False),
    yaxis=dict(title=None, showgrid=False, zeroline=False, showticklabels=False),
)

layout_with_200px = Layout(width="200px")
