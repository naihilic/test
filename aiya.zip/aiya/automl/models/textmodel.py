from IPython.display import display, HTML, clear_output
from aiya.automl.models.basemodel import BaseModel
from ipywidgets import (
    widgets,
    interact_manual,
    Label,
    SelectMultiple,
    Select,
    HBox,
    VBox,
    Layout,
    Output,
)
from aiya.constants import *
import yaml
import seaborn as sns
import copy
import matplotlib.pyplot as plt


class TextModel(BaseModel):
    def __init__(self):
        from aiya.automl.aidumodel import AIDUTextModel

        self.model = AIDUTextModel()
        self.model.name = None
        super().__init__()
        self.feature_view_comp = [25, 25, 25, 25]

    def getFeaturesByContent(self):
        return {
            column: {
                "inputs": self.INPUT_DTYPE_OPTIONS[str(dType)]["options"],
                "outputs": self.OUTPUT_DTYPE_OPTIONS[str(dType)]["options"],
                "type": self.INPUT_DTYPE_OPTIONS[str(dType)]["options"][0],
                "input": True,
                "output": False,
                "encoders": [
                    "embed",
                    "parallel_cnn",
                    "stacked_cnn",
                    "stacked_parallel_cnn",
                    "rnn",
                    "cnnrnn",
                ],
                "encoder": "embed",
                "decoders": ["generator", "tagger"],
                "decoder": "generator",
            }
            for column, dType in zip(self.content.columns, self.content.dtypes)
        }

    def firstQuarter(self):
        self.colSel.options = list(self.features.keys())
        self.colSel.value = list(self.features.keys())[0]
        return [Label("Columns "), self.colSel]

    def secondQuarter(self):
        self.inputSel.value = self.features[self.colSel.value]["input"]
        self.outputSel.value = self.features[self.colSel.value]["output"]
        self.typeSel.options = self.features[self.colSel.value]["inputs"]
        self.typeSel.value = self.features[self.colSel.value]["type"]

        return [
            Label("input"),
            self.inputSel,
            Label("output"),
            self.outputSel,
            Label("type"),
            self.typeSel,
        ]

    def thirdQuarter(self):
        # empty=Select(rows=11, layout=Layout(visibility='hidden', width='25%' ))
        self.infoOut = Output(layout=self.inner_width)
        with self.infoOut:
            display(self.currColUniqueValue(self.colSel.value))
        self.featureOptionSel = Select(
            options=self.features[self.colSel.value]["encoders"],
            value=self.features[self.colSel.value]["encoder"],
            layout=self.inner_width,
            rows=6,
        )
        self.featureOptionSel.observe(self.on_featureOption, names="value")
        self.featureOptionLab = Label("encoder")
        self.featureOptionVisible()
        return [
            Label("feature info"),
            self.infoOut,
            self.featureOptionLab,
            self.featureOptionSel,
        ]

    def fourthQuarter(self):
        return []

    ##temporary
    def featureOptionVisible(self):
        self.featureOptionSel.unobserve(self.on_featureOption, names="value")
        self.featureOptionSel.value = None

        if self.features[self.colSel.value]["type"] in ["text", "text_ko"]:
            self.featureOptionSel.disabled = False
        else:
            self.featureOptionSel.disabled = True

        if self.inputSel.value:
            self.featureOptionSel.options = self.features[self.colSel.value]["encoders"]
            self.featureOptionSel.value = self.features[self.colSel.value]["encoder"]
            self.featureOptionLab.value = "encoder"
        if self.outputSel.value:
            self.featureOptionSel.options = self.features[self.colSel.value]["decoders"]
            self.featureOptionSel.value = self.features[self.colSel.value]["decoder"]
            self.featureOptionLab.value = "decoder"
        self.featureOptionSel.observe(self.on_featureOption, names="value")

    def on_colSel(self, change):
        new_value = change["new"]
        self.set_colSel(new_value)
        self.featureOptionVisible()
        with self.infoOut:
            clear_output()
            display(self.currColUniqueValue(new_value))

    def on_inputSel(self, change):
        new_value = change["new"]
        self.set_inputSel(new_value)
        self.featureOptionVisible()

    def on_outputSel(self, change):
        new_value = change["new"]
        self.set_outputSel(new_value)
        self.featureOptionVisible()

    def on_typeSel(self, change):
        new_value = change["new"]
        self.features[self.colSel.value]["type"] = new_value
        self.featureOptionVisible()

    def on_featureOption(self, change):
        if self.inputSel.value:
            self.features[self.colSel.value]["encoder"] = change["new"]
        if self.outputSel.value:
            self.features[self.colSel.value]["decoder"] = change["new"]

    def train_precondition(self):
        if self.model.name is None:
            return False
        for value in self.features.values():
            if value["output"]:
                return True
        with self.resultArea:
            clear_output()
            display("Ouput Column이 지정되지 않았습니다.")
        return False

    MODEL_TITLE = "<h3>Text Modeling - Feature Configuration </h3>"
    INPUT_DTYPE_OPTIONS = {
        "int64": {"options": ["numerical", "binary", "category", "date"]},
        "int32": {"options": ["numerical", "binary", "category", "date"]},
        "float64": {"options": ["numerical", "category"]},
        "float32": {"options": ["numerical", "category"]},
        "object": {"options": ["category", "text", "text_ko", "binary", "date"]},
        "category": {"options": ["category", "binary", "date"]},
        "bool": {"options": ["binary"]},
    }

    OUTPUT_DTYPE_OPTIONS = {
        "int64": {"options": ["numerical", "binary", "category"]},
        "int32": {"options": ["numerical", "binary", "category"]},
        "float64": {"options": ["numerical", "category"]},
        "float32": {"options": ["numerical", "category"]},
        "object": {"options": ["category", "text", "text_ko", "binary"]},
        "category": {"options": ["category", "binary"]},
        "bool": {"options": ["binary"]},
    }
