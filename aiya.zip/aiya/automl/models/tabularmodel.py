from ipywidgets import Select, Label, HBox, Output
from aiya.automl.models.basemodel import BaseModel
import pandas as pd
from functools import reduce
from IPython.display import display, HTML, clear_output


class TabularModel(BaseModel):
    def __init__(self):
        from aiya.automl.aidumodel import AIDUTabularModel

        self.model = AIDUTabularModel()
        self.model.name = None
        super().__init__()
        self.feature_view_comp = [25, 25, 25, 25]

    def getFeaturesByContent(self):
        return {
            column: {
                "inputs": self.INPUT_DTYPE_OPTIONS[str(dType)]["options"],
                "outputs": self.OUTPUT_DTYPE_OPTIONS[str(dType)]["options"],
                "type": self.INPUT_DTYPE_OPTIONS[str(dType)]["options"][0],
                "input": False if self.content.isna().all()[column] else True,
                "output": False,
                "allNaN": True if self.content.isna().all()[column] else False,
            }
            for column, dType in zip(self.content.columns, self.content.dtypes)
        }

    def firstQuarter(self):
        self.colSel.options = list(self.features.keys())
        self.colSel.value = list(self.features.keys())[0]
        return [Label("Columns "), self.colSel]

    def secondQuarter(self):
        self.inputSel.value = self.features[self.colSel.value]["input"]
        self.outputSel.value = self.features[self.colSel.value]["output"]
        self.typeSel.options = self.features[self.colSel.value]["inputs"]
        self.typeSel.value = self.features[self.colSel.value]["type"]
        self.__second_quarter_disabler(self.colSel.value)
        return [
            Label("input"),
            self.inputSel,
            Label("output"),
            self.outputSel,
            Label("type"),
            self.typeSel,
        ]

    def thirdQuarter(self):
        self.infoOut = Output(layout=self.inner_width)
        with self.infoOut:
            display(self.currColUniqueValue(self.colSel.value))
        return [Label("feature info"), self.infoOut]

    def fourthQuarter(self):
        return []

    def currColUniqueValue(self, column):
        dropDf = self.content[column].dropna(how="any")
        dropUniqueDf = pd.Series(dropDf.unique())
        dropUniqueDf.sort_values(inplace=True)
        if self.features[column]["allNaN"]:
            return Label("There is no Value in this Column")
        elif dropUniqueDf.empty:
            return pd.DataFrame()
        else:
            str_v = (
                reduce(lambda x, y: str(x) + " " + str(y), dropUniqueDf)
                if dropUniqueDf.size <= 10
                else reduce(lambda x, y: str(x) + " " + str(y), dropUniqueDf[:5])
                + " ... "
                + str(dropUniqueDf.iloc[-1])
            )
            return pd.DataFrame(
                [dropDf.size, dropUniqueDf.size, str_v],
                index=["total", "unique", "value"],
                columns=[column],
            )

    def on_colSel(self, change):
        new_value = change["new"]
        self.set_colSel(new_value)
        self.__second_quarter_disabler(new_value)
        with self.infoOut:
            clear_output()
            display(self.currColUniqueValue(new_value))

    def on_inputSel(self, change):
        new_value = change["new"]
        self.set_inputSel(new_value)

    def on_outputSel(self, change):
        new_value = change["new"]
        self.set_outputSel(new_value)

    def on_typeSel(self, change):
        new_value = change["new"]
        self.features[self.colSel.value]["type"] = new_value

    def train_precondition(self):
        if self.model.name is None:
            return False
        for value in self.features.values():
            if value["output"]:
                return True
        with self.resultArea:
            clear_output()
            display("Ouput Column이 지정되지 않았습니다.")
        return False

    def __second_quarter_disabler(self, column):
        if self.features[column]["allNaN"]:
            self.inputSel.disabled = True
            self.outputSel.disabled = True
            self.typeSel.disabled = True
        else:
            self.inputSel.disabled = False
            self.outputSel.disabled = False
            self.typeSel.disabled = False

    ##constants
    MODEL_TITLE = "<h3>Vanilla Modeling - Feature Configuration </h3>"
    INPUT_DTYPE_OPTIONS = {
        "int64": {"options": ["numerical", "binary", "category", "date"]},
        "int32": {"options": ["numerical", "binary", "category", "date"]},
        "float64": {"options": ["numerical", "category"]},
        "float32": {"options": ["numerical", "category"]},
        "object": {"options": ["category", "binary", "date"]},
        "category": {"options": ["category", "binary", "date"]},
        "bool": {"options": ["binary"]},
    }
    OUTPUT_DTYPE_OPTIONS = {
        "int64": {"options": ["numerical", "binary", "category"]},
        "int32": {"options": ["numerical", "binary", "category"]},
        "float64": {"options": ["numerical", "category"]},
        "float32": {"options": ["numerical", "category"]},
        "object": {"options": ["category", "binary"]},
        "category": {"options": ["category", "binary"]},
        "bool": {"options": ["binary"]},
    }
