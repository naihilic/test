from IPython.display import display, HTML, clear_output
import pandas as pd
from ipywidgets import widgets, Label, Layout, Select, HBox, VBox, Output, Button
from aiya.utils.uploadutils import getDfFromByte, get_properRadio, getMetaAndContent
from aiya.context.context import context as ctx
from aiya.utils.ziputils import zip_dir
from functools import reduce
import copy
from aiya.ui.tools import display_download
from aiya.ui import tools as uit
import numpy as np


class BaseModel:
    inner_width = Layout(width="95%")
    half_width = Layout(width="50%")

    def __init__(self):
        self.content = ctx.content.select_dtypes(list(self.INPUT_DTYPE_OPTIONS.keys()))
        self.content = self.content[
            list(
                filter(
                    lambda col: (
                        np.issubdtype(self.content[col].dtype, np.number)
                        and self.content[col].std() > 0
                    )
                    or (not np.issubdtype(self.content[col].dtype, np.number)),
                    self.content.columns,
                )
            )
        ]

        self.features = self.getFeaturesByContent()
        self.baseArea = Output()
        self.featureArea = Output()
        self.nameArea = Output()
        self.configArea = Output()
        self.resultArea = Output()

    def main(self):
        with self.baseArea:
            clear_output()
            display(HTML(self.MODEL_TITLE))
            display(self.nameArea)
            display(self.featureArea)
            display(self.configArea)
            display(HTML("<hr>"))
            display(self.resultArea)
            display(HTML("<hr>"))
        display(self.baseArea)
        self.nameAreaView()

    def nameAreaView(self):
        with self.nameArea:
            clear_output()
            titleBox = []
            modelNameText = widgets.Text(
                value=self.model.name,
                placeholder="새 모델 이름 입력",
                disabled=False,
                continuous_update=False,
            )
            titleBox.extend([Label("Model Name: "), modelNameText])
            newModelBtn = widgets.Button(description="모델 만들기")
            titleBox.extend([newModelBtn])
            newModelResult = Label("")
            titleBox.extend([newModelResult])
            display(HBox(titleBox))

        def on_newModel(btn):
            if modelNameText.value == "":
                newModelResult.value = "새로운 모델 이름을 정해주세요"
            else:
                modelName = modelNameText.value
                if modelName in self.model.preModels:
                    newModelResult.value = "'" + modelName + "'은 이미 존재하는 모델 이름입니다."
                    modelNameText.value = (
                        self.model.name if self.model.name != None else ""
                    )
                else:
                    self.model.name = modelName
                    modelNameText.close()
                    newModelBtn.close()
                    newModelResult.value = modelName
                    self.featureAreaView()
                    self.configAreaView()

        newModelBtn.on_click(on_newModel)

    def featureAreaView(self):

        self.colSel = Select(layout=self.inner_width, rows=20)
        self.inputSel = Select(
            layout=self.inner_width, options=[("Yes", True), ("No", False)], rows=3
        )
        self.outputSel = Select(
            layout=self.inner_width, options=[("Yes", True), ("No", False)], rows=3
        )
        self.typeSel = Select(layout=self.inner_width)

        quarter_views = [
            self.firstQuarter(),
            self.secondQuarter(),
            self.thirdQuarter(),
            self.fourthQuarter(),
        ]
        with self.featureArea:
            clear_output()
            display(HTML("<hr>"))
            display(HTML("<h5> Feature Configuration </h5>"))
            quarters = []
            for i, size in enumerate(self.feature_view_comp):
                box = VBox(layout=Layout(width=str(size) + "%"))
                box.children = quarter_views[i]
                quarters.extend([box])
            display(HBox(quarters))

        self.colSel.observe(self.on_colSel, names="value")
        self.inputSel.observe(self.on_inputSel, names="value")
        self.outputSel.observe(self.on_outputSel, names="value")
        self.typeSel.observe(self.on_typeSel, names="value")

    def configAreaView(self):
        with self.configArea:
            clear_output()
            display(HTML("<hr>"))
            display(HTML("<h5> Training Configuration </h5>"))
            epochSlider = widgets.IntSlider(
                value=self.model.training["epochs"],
                min=1,
                max=1000,
                step=10,
                continuous_update=False,
            )
            batchSlider = widgets.FloatLogSlider(
                value=self.model.training["batch_size"],
                base=2,
                min=0,
                max=20,
                step=1,
                continuous_update=False,
                readout_format="d",
            )
            display(
                VBox([Label("Epochs"), epochSlider]),
                VBox([Label("Batch size"), batchSlider]),
            )
            btnTrain = widgets.Button(description="train(local)")

            def set_modeling_config(btn):
                self.model.training = {
                    "batch_size": int(batchSlider.value),
                    "epochs": int(epochSlider.value),
                }
                self.on_train()

            btnTrain.on_click(set_modeling_config)
            display(btnTrain)

    def on_colSel(self, change):
        pass

    def on_inputSel(self, change):
        pass

    def on_outputSel(self, change):
        pass

    def on_typeSel(self, change):
        pass

    def featureOptionVisible(self):
        pass

    # Template method for observe
    def set_colSel(self, new_value):
        self.outputSel.unobserve(self.on_outputSel, names="value")
        self.inputSel.unobserve(self.on_inputSel, names="value")
        self.inputSel.value = self.features[new_value]["input"]
        self.outputSel.value = self.features[new_value]["output"]
        self.set_typeSel()
        self.outputSel.observe(self.on_outputSel, names="value")
        self.inputSel.observe(self.on_inputSel, names="value")

    def set_inputSel(self, new_value):
        self.outputSel.unobserve(self.on_outputSel, names="value")
        self.features[self.colSel.value]["input"] = new_value
        if new_value:
            if self.features[self.colSel.value]["output"]:
                self.features[self.colSel.value]["output"] = not new_value
                self.outputSel.value = self.features[self.colSel.value]["output"]
            self.features[self.colSel.value]["type"] = self.features[self.colSel.value][
                "inputs"
            ][0]
        self.outputSel.observe(self.on_outputSel, names="value")
        self.set_typeSel()

    def set_outputSel(self, new_value):
        self.inputSel.unobserve(self.on_inputSel, names="value")
        self.features[self.colSel.value]["output"] = new_value
        if new_value:
            self.features[self.colSel.value]["type"] = self.features[self.colSel.value][
                "outputs"
            ][0]
            if self.features[self.colSel.value]["input"]:
                self.features[self.colSel.value]["input"] = not new_value
                self.inputSel.value = self.features[self.colSel.value]["input"]
        self.inputSel.observe(self.on_inputSel, names="value")
        self.set_typeSel()

    def set_typeSel(self):
        self.typeSel.unobserve(self.on_typeSel, names="value")
        self.typeSel.value = None
        if not self.inputSel.value and not self.outputSel.value:
            self.typeSel.options = []
        else:
            if self.outputSel.value:
                self.typeSel.options = self.features[self.colSel.value]["outputs"]
            if self.inputSel.value:
                self.typeSel.options = self.features[self.colSel.value]["inputs"]
            self.typeSel.value = self.features[self.colSel.value]["type"]
        self.typeSel.observe(self.on_typeSel, names="value")

    ######## Trainig Button ########
    def on_train(self):
        self.resultArea.clear_output()
        if self.train_precondition():
            with self.resultArea:
                import tensorflow as tf

                tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)
                zip_file = self.model.train(self.features, self.content)
                self.model.plot()
                filename = self.model.name + ".zip"
                display_download(
                    data=zip_file, filename=filename, title="Download Model"
                )

    def currColUniqueValue(self, column):
        dropDf = self.content[column].dropna(how="any")
        dropUniqueDf = pd.Series(dropDf.unique())
        dropUniqueDf.sort_values(inplace=True)
        if dropUniqueDf.empty:
            return pd.DataFrame()
        else:
            str_v = (
                reduce(lambda x, y: str(x) + " " + str(y), dropUniqueDf)
                if dropUniqueDf.size <= 10
                else reduce(lambda x, y: str(x) + " " + str(y), dropUniqueDf[:5])
                + " ... "
                + str(dropUniqueDf.iloc[-1])
            )
            return pd.DataFrame(
                [dropDf.size, dropUniqueDf.size, str_v],
                index=["total", "unique", "value"],
                columns=[column],
            )

    def on_loadModel(self, preModelName):
        self.resultArea.clear_output()
        self.model.name = preModelName["new"]

        def on_catalogPrediction(btn):
            df = ctx.getCatalogByName(catalogs.value)
            self.model.predict(df)

        with self.resultArea:
            display(
                HBox([widgets.HTML("* Loaded Model name : " + preModelName["new"])])
            )
            display_download(
                zip_dir(self.model.modelLoadPath),
                self.model.name + ".zip",
                "Download Model",
            )
            self.model.plot()
            uploadPred = widgets.FileUpload(
                accept=".csv, .csv_, .json, .xls, .xlsx", multiple=False
            )
            uploadPred.observe(self.on_uploadFilePrediction, names="value")
            catalogs = Select(options=ctx.catalogNames, index=0)
            left = VBox([Label("PC에서 업로드"), uploadPred])
            catalogBtn = Button(description="예측하기")

            catalogBtn.on_click(on_catalogPrediction)
            catalogBox = HBox([catalogs, catalogBtn])

            right = VBox([Label("카탈로그 사용"), catalogBox])

            display(VBox([widgets.Label("* 예측 데이터 업로드 하기"), HBox([left, right])]))
            display(self.optionOut)

    def on_uploadFilePrediction(self, data):
        def on_predictFile(btn):
            df = getDfFromByte(content, dOption, fileName)
            self.model.predict(df)
            # display(HTML('* Saved in ' +self.model.predictPath))

        def on_sepOption(change):
            from aiya.constants import CSV_OPTION

            if change["new"] in [x[1] for x in CSV_OPTION]:
                dOption["sep"] = change["new"]
            else:
                dOption["orient"] = change["new"]

        uploaded_data = data["new"]
        fileName, _, content = getMetaAndContent(uploaded_data)
        dOption = {"sep": ",", "orient": "records"}
        with self.optionOut:
            clear_output()
            display(HBox([Label("File name for prediction : "), Label(fileName)]))
            rButtons = get_properRadio(content, dOption, fileName)
            rButtons.observe(on_sepOption, names="value")
            display(rButtons)
            display(HBox([uit.createButton("예측하기", on_predictFile)]))

    def predictView(self):
        self.optionOut = Output()
        with self.baseArea:
            clear_output()
            display(HTML(self.MODEL_TITLE))
            if len(self.model.preModels) > 0:
                selModel = Select(
                    options=self.model.preModels,
                    value=None,
                    disabled=False,
                    Description="Models",
                    rows=15,
                )
                selModel.observe(self.on_loadModel, names="value")
                display(HBox([widgets.Label("* Load Model: "), selModel]))
            else:
                display(HTML("There is not Model"))
            display(self.resultArea)
        display(self.baseArea)

    @property
    def featuresView(self):
        featureView = ("input_features", "output_features")
        printView = ("name", "type")
        tmpModel = self.model.genModelDef(self.features)
        return {
            feature: [
                {view: fDict[view] for view in fDict if view in printView}
                for fDict in tmpModel[feature]
                if tmpModel[feature]
            ]
            for feature in featureView
        }
