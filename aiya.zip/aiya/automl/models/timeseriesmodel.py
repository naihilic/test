from aiya.automl.models.basemodel import BaseModel
from IPython.display import display, HTML, clear_output
from ipywidgets import (
    widgets,
    Dropdown,
    Label,
    IntSlider,
    Select,
    HBox,
    VBox,
    Output,
    Button,
    Layout,
    BoundedIntText,
)
from aiya.constants import *
from aiya.ui.layout import layout_with_200px
import seaborn as sns
import matplotlib.pyplot as plt


class TimeseriesModel(BaseModel):
    feature_view_num = 3

    def __init__(self):
        from aiya.automl.aidumodel import AIDUTimeseriesModel

        self.model = AIDUTimeseriesModel()
        self.model.name = None
        super().__init__()
        self.feature_view_comp = [25, 25, 25, 25]

    def getFeaturesByContent(self):
        return {
            column: {
                "types": self.INPUT_DTYPE_OPTIONS[str(dType)]["options"],
                "type": self.INPUT_DTYPE_OPTIONS[str(dType)]["options"][0],
                "input": True,
                "output": 0,
                "ludwigParams": {
                    "encoder": self.LUDWIG_PARAMS["encoder"],
                    "cell_type": self.LUDWIG_PARAMS["cell_types"][0],
                    "num_layers": self.LUDWIG_PARAMS["num_layer_range"][0],
                    "state_size": self.LUDWIG_PARAMS["state_size_range"][0],
                },
                "customParams": {
                    "sequenceLen": self.CUSTOM_PARMS["sequenceLen_range"][0],
                    "normMethod": self.CUSTOM_PARMS["normal_methods"][0],
                },
            }
            for column, dType in zip(self.content.columns, self.content.dtypes)
        }

    def firstQuarter(self):
        self.colSel.options = list(self.features.keys())
        self.colSel.value = list(self.features.keys())[0]
        return [Label("Columns "), self.colSel]

    def secondQuarter(self):
        ##from base
        self.inputSel.value = self.features[self.colSel.value]["input"]
        self.outputSel.value = self.getBooleanByNum(
            self.features[self.colSel.value]["output"]
        )
        self.typeSel.options = self.features[self.colSel.value]["types"]
        self.typeSel.rows = 2
        self.typeSel.value = self.features[self.colSel.value]["type"]

        ##timeseries specialized
        self.outputNum = IntSlider(
            min=0,
            max=32,
            layout=self.inner_width,
            value=self.features[self.colSel.value]["output"],
        )
        self.outputNum.disabled = True
        self.outputNum.observe(self.on_outputNum, names="value")
        return [
            Label("input"),
            self.inputSel,
            Label("output"),
            self.outputSel,
            self.outputNum,
            Label("type"),
            self.typeSel,
        ]

    def thirdQuarter(self):
        colSel = self.colSel.value
        customParams = self.features[colSel]["customParams"]
        self.methodSel = Dropdown(
            options=self.CUSTOM_PARMS["normal_methods"],
            value=customParams["normMethod"],
        )
        self.lengthSel = BoundedIntText(
            min=self.CUSTOM_PARMS["sequenceLen_range"][0],
            max=self.CUSTOM_PARMS["sequenceLen_range"][1],
            value=customParams["sequenceLen"],
        )
        ludwigParams = self.features[colSel]["ludwigParams"]
        self.cellSel = Dropdown(
            options=self.LUDWIG_PARAMS["cell_types"], value=ludwigParams["cell_type"]
        )
        self.numLayerSel = BoundedIntText(
            min=self.LUDWIG_PARAMS["num_layer_range"][0],
            max=self.LUDWIG_PARAMS["num_layer_range"][1],
            value=ludwigParams["num_layers"],
        )
        self.cellsizeSel = BoundedIntText(
            min=self.LUDWIG_PARAMS["state_size_range"][0],
            max=self.LUDWIG_PARAMS["state_size_range"][1],
            value=ludwigParams["state_size"],
        )

        self.methodSel.layout = self.half_width
        self.lengthSel.layout = self.half_width
        self.cellSel.layout = self.half_width
        self.numLayerSel.layout = self.half_width
        self.cellsizeSel.layout = self.half_width

        self.methodSel.observe(self.on_norm_method, names="value")
        self.lengthSel.observe(self.on_sec_len, names="value")
        self.cellSel.observe(self.on_cell_type, names="value")
        self.numLayerSel.observe(self.on_num_layer, names="value")
        self.cellsizeSel.observe(self.on_state_size, names="value")

        return [
            widgets.HTML("<b>Preprocess Config</b>"),
            HBox([Label("Norm Method"), self.methodSel]),
            HBox([Label("Sequence Length"), self.lengthSel]),
            widgets.HTML("<hr/>"),
            widgets.HTML("<b>Hyper Parameter Config</b>"),
            HBox([Label("Cell Type"), self.cellSel]),
            HBox([Label("Num. of Layer"), self.numLayerSel]),
            HBox([Label("Cell State Size"), self.cellsizeSel]),
        ]

    def fourthQuarter(self):
        self.infoOut = Output(layout=self.inner_width)
        with self.infoOut:
            sns.distplot(self.content[self.colSel.value].dropna())
            plt.show()
        return [Label("feature info"), self.infoOut]

    def getBooleanByNum(self, num):
        return 1 if num > 0 else 0

    def on_colSel(self, change):
        new_value = change["new"]
        self.inputSel.value = self.features[new_value]["input"]
        self.outputSel.value = self.getBooleanByNum(self.features[new_value]["output"])

        customParams = self.features[new_value]["customParams"]
        self.methodSel.value = customParams["normMethod"]
        self.lengthSel.value = customParams["sequenceLen"]

        ludwigParams = self.features[new_value]["ludwigParams"]
        self.cellSel.value = ludwigParams["cell_type"]
        self.numLayerSel.value = ludwigParams["num_layers"]
        self.cellsizeSel.value = ludwigParams["state_size"]

        with self.infoOut:
            clear_output()
            sns.distplot(self.content[self.colSel.value].dropna())
            plt.show()

    def on_inputSel(self, change):
        new_value = change["new"]
        self.features[self.colSel.value]["input"] = new_value

    def on_outputSel(self, change):
        new_value = change["new"]
        self.outputNum.unobserve(self.on_outputNum, names="value")
        self.outputNum.min = int(new_value)
        self.outputNum.observe(self.on_outputNum, names="value")
        self.outputNum.disabled = not new_value
        if new_value:
            for name, attrs in self.features.items():
                if name is not self.colSel.value:
                    attrs["output"] = int(not new_value)
                elif attrs["output"] is 0:
                    attrs["output"] = int(new_value)
        else:
            self.features[self.colSel.value]["output"] = int(new_value)
        self.outputNum.value = self.features[self.colSel.value]["output"]

    def on_outputNum(self, change):
        new_value = change["new"]
        self.features[self.colSel.value]["output"] = new_value

    @property
    def getLudwigParams(self):
        return self.features[self.colSel.value]["ludwigParams"]

    @property
    def getCustomParams(self):
        return self.features[self.colSel.value]["customParams"]

    def on_norm_method(self, change):
        new_value = change["new"]
        self.getCustomParams["normMethod"] = new_value

    def on_sec_len(self, change):
        new_value = change["new"]
        self.getCustomParams["sequenceLen"] = new_value

    def on_cell_type(self, change):
        new_value = change["new"]
        self.getLudwigParams["cell_type"] = new_value

    def on_num_layer(self, change):
        new_value = change["new"]
        self.getLudwigParams["num_layers"] = new_value

    def on_state_size(self, change):
        new_value = change["new"]
        self.getLudwigParams["state_size"] = new_value

    def train_precondition(self):
        if self.model.name is None:
            return False
        for value in self.features.values():
            if value["output"] > 0:
                return True
        with self.resultArea:
            clear_output()
            display("Ouput Column이 지정되지 않았습니다.")
        return False

    MODEL_TITLE = "<h3>Time-series Modeling -  Output univariate time series </h3>"
    INPUT_DTYPE_OPTIONS = {
        "int64": {"options": ["timeseries"]},
        "int32": {"options": ["timeseries"]},
        "float64": {"options": ["timeseries"]},
        "float32": {"options": ["timeseries"]},
    }
    LUDWIG_PARAMS = {
        "encoder": "rnn",
        "cell_types": ["rnn", "lstm", "gru"],
        "num_layer_range": [1, 10],
        "state_size_range": [1, 256],
    }
    CUSTOM_PARMS = {
        "sequenceLen_range": [1, 32],
        "normal_methods": ["Standard", "Minmax", "Tanh", "Sigmoid"],
    }
