from IPython.display import display, HTML, clear_output
from ipywidgets import Button, Output

model_output = Output()


def on_start(btn):
    from aiya.automl.models import tabularmodel, timeseriesmodel, textmodel

    if btn.value == "Tabular_Vanilla":
        model = tabularmodel.TabularModel()
    elif btn.value == "Text_Vanilla":
        model = textmodel.TextModel()
    elif btn.value == "Uni_variate":
        model = timeseriesmodel.TimeseriesModel()
    else:
        return
    with model_output:
        clear_output()
        model.main()


def on_pred(btn):
    from aiya.automl.models import tabularmodel, timeseriesmodel, textmodel

    if btn.value == "Tabular_Vanilla":
        model = tabularmodel.TabularModel()
    elif btn.value == "Text_Vanilla":
        model = textmodel.TextModel()
    elif btn.value == "Uni_variate":
        model = timeseriesmodel.TimeseriesModel()
    else:
        return
    with model_output:
        clear_output()
        model.predictView()


def menu():
    from aiya.constants import LEARNING_MODELS
    from aiya.ui.controls import createProjectCatalogSelection

    startBtn = Button(description="시작")
    startBtn.on_click(on_start)
    predBtn = Button(description="예측")
    predBtn.on_click(on_pred)
    clear_output()
    display(HTML("<h3>" + "AI 모델링" + "</h3>"))
    createProjectCatalogSelection(LEARNING_MODELS, startBtn, predBtn)
    display(HTML("<hr>"))
    display(model_output)
