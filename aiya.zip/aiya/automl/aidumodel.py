"""
        Author: Byoungkyu.ji
"""
import os
from IPython.display import display
from aiya.context.context import context as ctx
from ludwig.globals import (
    TRAIN_SET_METADATA_FILE_NAME,
    MODEL_HYPERPARAMETERS_FILE_NAME,
    TRAINING_PROGRESS_FILE_NAME,
)
from ludwig.constants import TRAINING
import pandas as pd
from aiya.ui.tools import display_download
from aiya.utils.ziputils import zip_dir
from pathlib import Path
from aiya.constants import (
    OUTPUT_LUDWIG_PARAMS,
    INPUT_LUDWIG_PARAMS,
    OUTPUT_CUSTOM_PARAMS,
    INPUT_CUSTOM_PARAMS,
    JSON_OPTION,
    CSV_OPTION,
)
import json


class AIDUBaseModel:
    ludwigCache = {}

    def __init__(self):
        self._modelType = None
        self.name = None
        self.training = {"batch_size": 128, "epochs": 100}

    def loadLudwigModel(self, modelLoadPath):
        if modelLoadPath in AIDUBaseModel.ludwigCache:
            return AIDUBaseModel.ludwigCache[modelLoadPath]

        from ludwig.api import LudwigModel

        ludwigModel = LudwigModel.load(modelLoadPath)

        AIDUBaseModel.ludwigCache[modelLoadPath] = ludwigModel

        return ludwigModel

    ################ Model Config setting ################
    def makeDef(self, inputFeatures, outputFeatures):
        return {
            "preprocessing": {
                "category": {"missing_value_strategy": "fill_with_mode"},
                "numerical": {"normalization": "zscore"},
            },
            "input_features": inputFeatures,
            "output_features": outputFeatures,
            "training": self.training,
            #'combiner':{}
        }

    def genModelDef(self, features):
        inputFeatures = []
        outputFeatures = []
        for name, attrs in features.items():
            if attrs["input"]:
                inputFeature = {"name": name, "type": attrs["type"]}
                inputFeature.update(INPUT_LUDWIG_PARAMS[attrs["type"]])
                inputFeatures.append(inputFeature)
            if attrs["output"]:
                outputFeature = {"name": name, "type": attrs["type"]}
                outputFeature.update(OUTPUT_LUDWIG_PARAMS[attrs["type"]])
                outputFeatures.append(outputFeature)
        return self.makeDef(inputFeatures, outputFeatures)

    # get Dynamic path by current catalog
    @property
    def outputPath(self):
        return Path(
            os.path.join(
                os.getcwd(), ctx.currProjectName, ctx.currCatalogName, self._modelType
            )
        )

    @property
    def modelResumePath(self):
        return Path(self.outputPath) / self.name

    @property
    def modelLoadPath(self):
        return Path(self.modelResumePath) / "model"

    def loadTrainingStats(self, modelResumePath):
        try:
            with open(modelResumePath / "training_statistics.json") as ts:
                trainStats = json.load(ts)
        except IOError:
            # display('empty ')
            trainStats = None
        return trainStats

    def loadTrainingProgress(self, modelLoadPath):
        try:
            with open(modelLoadPath / TRAINING_PROGRESS_FILE_NAME) as pr:
                modelProgess = json.load(pr)
        except IOError:
            # display('학습이 제대로 되지 않았습니다.')
            modelProgess = None
        return modelProgess

    def loadTrainingMetaData(self, modelLoadPath):
        try:
            with open(modelLoadPath / TRAIN_SET_METADATA_FILE_NAME) as md:
                metaData = json.load(md)
        except IOError:
            # display('학습이 제대로 되지 않았습니다.')
            metaData = None
        return metaData

    def loadModelDefinition(self, modelLoadPath):
        try:
            with open(modelLoadPath / MODEL_HYPERPARAMETERS_FILE_NAME) as mf:
                modelDef = json.load(mf)
        except IOError:
            # display('학습이 제대로 되지 않았습니다.')
            modelDef = None
        return modelDef

    def loadTestStats(self, modelResumePath):
        try:
            with open(modelResumePath / "test_statistics.json") as ts:
                testStats = json.load(ts)
        except IOError:
            # display('현재 버전에서 새로운 모델을 만들어 주시기 바랍니다.')
            testStats = None
        return testStats

    @property
    def preModels(self):
        preModelPath = self.outputPath
        if os.path.exists(preModelPath):
            return [f for f in os.listdir(preModelPath)]
        else:
            return []

    def train(self, features, train_df):
        import logging
        from ludwig.data.preprocessing import get_split
        from ludwig.api import LudwigModel
        from ludwig.predict import save_test_statistics

        if not os.path.exists(self.modelResumePath):

            modelDef = self.genModelDef(features)
            ludwigModel = LudwigModel(modelDef, logging_level=logging.INFO)
            outputDf = self._preprocessDf(train_df, ludwigModel)
            ludwigModel.train(
                data_df=outputDf,
                output_directory=self.outputPath,
                experiment_name=self.name,
                model_name="",
                gpus=ctx.gpus,
            )

            test_df = outputDf[get_split(outputDf) == 2]
            _, testStats = ludwigModel.test(
                data_df=test_df,
                batch_size=modelDef["training"]["batch_size"],
                gpus=ctx.gpus,
            )
            save_test_statistics(testStats, ludwigModel.exp_dir_name)
        else:
            # TODO Handling when clicking train button twice
            pass
        zip_file = zip_dir(self.modelResumePath)
        return zip_file

    def resume(self, df, config, modelResumePath):

        import logging

        ludwigModel = self.loadLudwigModel(modelResumePath / "model")
        ludwigModel.model_definition["training"].update(config)
        ludwigModel.set_logging_level(logging.INFO)

        ludwigModel.train(data_df=df, model_resume_path=modelResumePath, gpus=ctx.gpus)

    def reload(self, df, config, modelLoadPath):
        import logging
        import datetime

        ludwigModel = self.loadLudwigModel(modelLoadPath)
        ludwigModel.model_definition["training"].update(config)
        ludwigModel.set_logging_level(logging.INFO)

        ludwigModel.train(
            data_df=df,
            model_load_path=modelLoadPath,
            output_directory=modelLoadPath.parent.parent,
            experiment_name=str(modelLoadPath.parent),
            model_name=str(int(datetime.datetime.now().timestamp())),
            gpus=ctx.gpus,
        )

    def plot(self, modelResumePath=None, modelLoadPath=None):
        import matplotlib
        import matplotlib.pyplot as plt
        import matplotlib.font_manager as fm
        import ludwig.visualize
        from aiya.ui import tools

        if modelResumePath is None:
            modelResumePath = self.modelResumePath
        if modelLoadPath is None:
            modelLoadPath = self.modelLoadPath

        modelDef = self.loadModelDefinition(modelLoadPath)
        modelMetaData = self.loadTrainingMetaData(modelLoadPath)
        trainStats = self.loadTrainingStats(modelResumePath)
        testStats = self.loadTestStats(modelResumePath)

        trainKey = "train" if "train" in trainStats.keys() else "training"
        outputFeatures = trainStats[trainKey].keys()  # modelDef['output_features']
        ftrSize = len(outputFeatures)
        outputItems = ["loss", "error", "accuracy"]  # r2, mean_absolute_error, mean...
        itmSize = len(outputItems)
        idxPlot = 0
        plt.figure(figsize=(20, 10 * ftrSize))
        for iFtr, feature in enumerate(outputFeatures):
            for iItm, item in enumerate(outputItems):
                # plt.subplot(ftrSize, itmSize, ftrSize*iFtr+iItm+1).set_title(feature+'-'+item)
                idxPlot = idxPlot + 1
                plt.subplot(ftrSize, itmSize, idxPlot).set_title(feature + "-" + item)
                if (
                    item not in trainStats[trainKey][feature].keys()
                ):  # ['train'][feature].keys():
                    plt.plot([0, 0], label="train")
                    plt.plot([1, 1], label="validation")
                    plt.plot([2, 2], label="test")
                else:
                    plt.plot(
                        trainStats[trainKey][feature][item], label="train"
                    )  # ['train'][feature][item], label='train')
                    plt.plot(
                        trainStats["validation"][feature][item], label="validation"
                    )
                    plt.plot(trainStats["test"][feature][item], label="test")
            plt.legend()

        if testStats:
            for output in modelDef["output_features"]:
                outFeatureType = output["type"]
                if outFeatureType == "category":
                    ludwig.visualize.confusion_matrix(
                        [testStats],
                        modelMetaData,
                        output["name"],
                        [10],
                        False,
                        model_names=modelResumePath.name,
                    )
                    ludwig.visualize.frequency_vs_f1(
                        [testStats],
                        modelMetaData,
                        output["name"],
                        [10],
                        model_names=modelResumePath.name,
                    )
                if outFeatureType == "binary":
                    ludwig.visualize.confusion_matrix(
                        [testStats],
                        modelMetaData,
                        output["name"],
                        [10],
                        False,
                        model_names=modelResumePath.name,
                    )
                    ludwig.visualize.roc_curves_from_test_statistics(
                        [testStats], output["name"], model_names=modelResumePath.name
                    )
                # set font & show it
                if ctx.fontName in [f.name for f in fm.fontManager.ttflist]:
                    matplotlib.rc("font", family=ctx.fontName)
                plt.show()

    def predict(self, dataFrame, modelLoadPath=None):
        if modelLoadPath is None:
            modelLoadPath = self.modelLoadPath

        ludwigModel = self.loadLudwigModel(modelLoadPath)
        outputDf = self._preprocessDf(dataFrame, ludwigModel)

        columns = list(dataFrame.columns)
        labels = [
            output["name"]
            for output in iter(ludwigModel.model_definition["output_features"])
        ]
        labels = [val for val in labels if val in columns]
        actuals = dataFrame[labels].rename(lambda x: x + "_actual", axis="columns")

        pred = ludwigModel.predict(outputDf, gpus=ctx.gpus)
        self._postprocessDf(pred, ludwigModel)
        pred = pd.concat([pred, actuals], axis="columns")
        csv = pred.to_csv(
            index=False, encoding="utf-16"
        )  # default uses utf-8 which might cause korean character crashed
        display_download(csv.encode("utf-16"), "result.csv")
        return pred, csv

    def _postprocessDf(self, dataFrame, ludwigModel):
        from ludwig.constants import PREDICTIONS

        outputFeatures = ludwigModel.model_definition["output_features"]
        for outputFeature in outputFeatures:
            name = outputFeature["name"]
            if outputFeature["type"] == "numerical":
                std = ludwigModel.train_set_metadata[name]["std"]
                mean = ludwigModel.train_set_metadata[name]["mean"]
                name = name + "_" + PREDICTIONS
                dataFrame[name] = (dataFrame[name] * std) + mean

    def _preprocessDf(self, dataFrame, ludwigModel):
        preprocessed = dataFrame.copy()
        outputFeatures = ludwigModel.model_definition["output_features"]
        inputFeatures = ludwigModel.model_definition["input_features"]
        for f in inputFeatures:
            if f["type"] == "date":
                preprocessed[f["name"]] = preprocessed[f["name"]].astype(str)
        return preprocessed

    ############### Utils ################
    def _normalization(self, df, col_name, method):
        import numpy as np

        if method == "Standard":
            return (df[col_name] - df[col_name].mean()) / (
                df[col_name].std() if df[col_name].std() != 0 else 1
            )
        elif method == "Minmax":
            return (df[col_name] - df[col_name].min()) / (
                df[col_name].max() - df[col_name].min()
            )
        elif method == "Tanh":

            return 0.5 * (
                np.tanh(
                    0.01
                    * (df[col_name] - df[col_name].mean())
                    / (df[col_name].std() if df[col_name].std() != 0 else 1)
                )
                + 1
            )
        elif method == "Sigmoid":
            return 1 / (1 + np.exp(-df[col_name]))
        else:
            return "There is no normalization method!"


class AIDUTabularModel(AIDUBaseModel):
    def __init__(self):
        super().__init__()
        self._modelType = "Tabular_Vanilla"


class AIDUTextModel(AIDUBaseModel):
    def __init__(self):
        super().__init__()
        self._modelType = "Text_Vanilla"

    def genModelDef(self, features):
        inputFeatures = []
        outputFeatures = []
        for name, attrs in features.items():
            if attrs["input"]:
                inputFeature = {"name": name, "type": attrs["type"]}
                inputFeature.update(INPUT_LUDWIG_PARAMS[attrs["type"]])
                inputFeatures.append(inputFeature)

                if attrs["type"] == "text":
                    inputFeature["preprocessing"] = {"word_tokenizer": "space_punct"}

                if attrs["type"] == "text_ko":
                    inputFeature["type"] = "text"
                    inputFeature["preprocessing"] = {"word_tokenizer": "konlpy"}

                if inputFeature["type"] == "text":
                    inputFeature["encoder"] = attrs["encoder"]

            if attrs["output"]:
                outputFeature = {"name": name, "type": attrs["type"]}
                if attrs["type"] == "text_ko":
                    outputFeature["type"] = "text"
                    outputFeature["preprocessing"] = {"word_tokenizer": "konlpy"}
                outputFeatures.append(outputFeature)

        return self.makeDef(inputFeatures, outputFeatures)


class AIDUTimeseriesModel(AIDUBaseModel):
    def __init__(self):
        super().__init__()
        self._modelType = "Uni_variate"

    def genModelDef(self, features):
        inputFeatures = []
        outputFeatures = []
        for name, attrs in features.items():
            if attrs["input"]:
                seqLen = attrs["customParams"]["sequenceLen"]
                normMethod = attrs["customParams"]["normMethod"]
                input_name = name + "_norm_" + normMethod + "_seqLen_" + str(seqLen)
                inputFeature = {"name": input_name, "type": attrs["type"]}
                inputFeature.update(attrs["ludwigParams"])
                inputFeatures.append(inputFeature)
            if attrs["output"] > 0:
                for num in range(attrs["output"]):
                    outputFeatures.append(
                        {"name": name + "_step_" + str(num + 1), "type": "numerical"}
                    )
        return self.makeDef(inputFeatures, outputFeatures)

    def _preprocessDf(self, dataFrame, ludwigModel):
        import re
        from ludwig.utils.data_utils import add_sequence_feature_column
        from aiya.utils.datautils import fillnaTimeseries

        preprocessed = dataFrame.copy()
        preprocessed = fillnaTimeseries(preprocessed)
        outputFeatures = ludwigModel.model_definition["output_features"]
        inputFeatures = ludwigModel.model_definition["input_features"]
        # TODO : multiple Output
        stepRegex = re.compile("_step_\d+")
        for outputFeature in outputFeatures:
            fullName = outputFeature["name"]
            stepAll = stepRegex.findall(fullName)
            outputName = stepRegex.sub("", fullName)
            if len(stepAll) == 1:
                step = int(stepAll[0].replace("_step_", ""))
                preprocessed[fullName] = preprocessed[outputName].shift(-step)
            else:
                pass  # TODO : ERROR
        for f in inputFeatures:
            if f["type"] == "timeseries":
                fullName = f["name"]
                norm = "_norm_[A-Za-z]+"
                seq = "_seqLen_\d+"
                pattern = re.compile(norm + seq)
                colName = pattern.sub("", fullName)
                normRegex = re.compile(norm)
                seqRegex = re.compile(seq)
                seqLenAll = seqRegex.findall(fullName)
                normMethodAll = normRegex.findall(fullName)
                if (len(seqLenAll) == 1) and (len(normMethodAll) == 1):
                    seqLen = int(seqLenAll[0].replace("_seqLen_", ""))
                    normMethod = normMethodAll[0].replace("_norm_", "")
                    preprocessed[colName] = self._normalization(
                        preprocessed, colName, normMethod
                    )
                    add_sequence_feature_column(preprocessed, colName, seqLen)
                    # renaming because of Ludwig API
                    preprocessed.rename(
                        columns={colName + "_feature": fullName}, inplace=True
                    )

                else:
                    print("RegexError ")
                    pass  # TODO : ERROR
        return preprocessed


if __name__ == "__main__":
    model = AIDUBaseModel()
