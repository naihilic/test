from IPython.display import display_javascript, display, HTML, clear_output
from aiya.context.context import context as ctx
from aiya.ui import tools as uit
import ipywidgets as widgets
from aiya.project import project
from aiya.catalog import catalog
from aiya.processing import processing
from aiya.analytics import analytics
from aiya.automl import automl
from aiya.execution import execution
from aiya.constants import STYLE
from aiya.settings import settings
import matplotlib
import aiya


def init():
    ##enable matplotlib korean font
    matplotlib.rc("font", family=ctx.fontName)
    matplotlib.rc("axes", unicode_minus=False)
    display(HTML(STYLE))
    ## warning level adjustemnt
    import warnings

    warnings.filterwarnings(
        "ignore", category=RuntimeWarning
    )  # runtime warning is to be supressed..
    ## initial menu of system
    # menu = ['프로젝트','데이터 카탈로그', '데이터 가공','데이터 분석','AI모델링']
    menu = ["프로젝트", "데이터 카탈로그", "데이터 분석", "AI모델링", "AI운영", "설정"]
    outputs = {i: widgets.Output() for i in range(len(menu))}
    # menuFuncs=[project.menu,catalog.menu,processing.menu,analytics.menu,automl.menu]
    menuFuncs = [
        project.menu,
        catalog.menu,
        analytics.menu,
        automl.menu,
        execution.menu,
        settings.menu,
    ]
    tab = widgets.Tab()
    tab.children = list(outputs.values())
    for i, title in outputs.items():
        tab.set_title(i, menu[i])

    def on_select(tab):
        tabIdx = tab["new"]
        outputWidget = outputs[tabIdx]
        with outputWidget:
            clear_output()
            menuFuncs[tabIdx]()

    # display(uit.createHBoxButtons(menu))
    tab.observe(on_select, names="selected_index")
    with outputs[0]:
        clear_output()
        project.menu()
    display(tab)
    # display(HTML(' * 현재 프로젝트 : ' + ctx.currProjectName))
    # display(HTML(' * 현재 카탈로그 : ' + str(ctx.currCatalogName)))


def addToolbar():
    scriptToolbar = """
if($(IPython.toolbar.selector.concat(' > #aiya')).length == 0) {
  IPython.toolbar.add_buttons_group([{
    'label'   : 'aiya',
    'icon'    : 'fa fa-angle-double-down',
    'callback': function() {
      IPython.notebook.insert_cell_below();
      var cell = IPython.notebook.get_cell(0);
      cell.set_text('from aiya.home import home\\nhome.init()');
      IPython.notebook.execute_cell(cell);
    }}], 'aiya');}"""
    display_javascript(scriptToolbar, raw=True)
