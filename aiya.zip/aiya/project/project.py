from IPython.display import display, HTML, clear_output


def on_createProject(projectName):
    from aiya.context.context import context as ctx

    ctx.newProject(projectName["new"])
    menu()


def on_changeProject(projectName):
    from aiya.context.context import context as ctx

    ctx.changeCurrProject(projectName["new"])
    menu()


def on_changeCatalog(catalogName):
    from aiya.context.context import context as ctx

    ctx.changeCurrCatalog(catalogName["new"])
    menu()


def menu():
    import ipywidgets as widgets
    from aiya.ui import tools as uit
    from aiya.context.context import context as ctx

    ## project
    ddProject = widgets.Dropdown(
        options=list(ctx.projectNames),
        value=ctx.currProjectName,
        description="",
        disabled=False,
    )
    ddProject.observe(on_changeProject, names="value")
    ## save as
    btnSaveProject = widgets.Button(description="저장")

    def on_saveProject(btn):
        from aiya.ui import tools as uit
        import aiya.project.repos.zadara as zdr

        zdr.save()

        """
        # repos options
        ## 1. azure
        btnAzure = widgets.Button(description='Azure')
        def on_azure(btn):
            import aiya.project.repos.azure as az
            az.save()
        btnAzure.on_click(on_azure)
        ## 2. zadara 
        btnZadara = widgets.Button(description='클라우드저장소')
        def on_zadara(btn):
            import aiya.project.repos.zadara as zdr
            zdr.save()
        btnZadara.on_click(on_zadara)
        # back button
        btnBackToMenu = widgets.Button(description='돌아가기')
        def on_backToProject(btn):
            menu()
        btnBackToMenu.on_click(on_backToProject)
        ## display
        clear_output()
        btnBack = widgets.Button(description='돌아가기')
        def on_back2Project(btn):
            menu()
        btnBack.on_click(on_back2Project)

        # display
        display(HTML(uit.createNavigationBar('home.project', title='저장하기')))
        if ctx.currUser is not None:
            display(widgets.HBox([widgets.Label('* 저장위치 선택: '), btnZadara]))
        display(HTML('<hr>'))
        display(btnBack)
        """

    btnSaveProject.on_click(on_saveProject)
    ## catalog
    ddCatalog = widgets.Dropdown(
        options=list(ctx.catalogNames),
        value=ctx.currCatalogName,
        description="",
        disabled=False,
    )
    ddCatalog.observe(on_changeCatalog, names="value")
    ## create project
    ttProject = widgets.Text(
        value="", placeholder="project name", disabled=False, continuous_update=False
    )
    ttProject.observe(on_createProject, names="value")
    ## load project
    ## 1. from azure
    btnAzure = widgets.Button(description="Azure")

    def on_azure(btn):
        import aiya.project.repos.azure as az

        az.load()

    btnAzure.on_click(on_azure)
    ## 2. from zadara
    btnZadara = widgets.Button(description="클라우드 저장소")

    def on_zadara(btn):
        import aiya.project.repos.zadara as zdr

        zdr.load()

    btnZadara.on_click(on_zadara)

    ## remove project
    btnRemoveProject = widgets.Button(description="삭제")

    def on_removeProject(btn):
        from aiya.context.context import context as ctx

        ctx.removeCurrProject()
        menu()

    btnRemoveProject.on_click(on_removeProject)
    # display
    clear_output()
    display(HTML("<h3>" + "프로젝트" + "</h3>"))
    # display(widgets.HBox([widgets.Label('* 현재 프로젝트: '), ddProject, btnSaveProject, btnRemoveProject]))
    display(widgets.HBox([widgets.Label("* 현재 프로젝트: "), ddProject, btnRemoveProject]))
    display(widgets.HBox([widgets.Label("* 현재 카탈로그: "), ddCatalog]))
    display(
        widgets.HBox(
            [widgets.Label("* 프로젝트 생성: "), ttProject, widgets.Label("<입력 후 엔터>")]
        )
    )
    # display(widgets.HBox([widgets.Label('* 프로젝트 불러오기: '), btnZadara])) # btnAzure
