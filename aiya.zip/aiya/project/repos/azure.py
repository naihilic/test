from IPython.display import display, HTML, clear_output
from aiya.ui import tools as uit

accountName = ""
accountKey = ""
chosenProjectName = ""


def load():
    import ipywidgets as widgets

    clear_output()
    ## account info
    def on_accountName(value):
        global accountName
        accountName = value["new"]

    wgtAccountName = widgets.Text(
        value=accountName,
        placeholder=accountName,
        disabled=False,
        continuous_update=False,
    )
    wgtAccountName.observe(on_accountName, names="value")

    ## account key
    def on_accountKey(value):
        global accountKey
        accountKey = value["new"]

    wgtAccountKey = widgets.Text(
        value=accountKey,
        placeholder=accountKey,
        disabled=False,
        continuous_update=False,
    )
    wgtAccountKey.observe(on_accountKey, names="value")

    ## action button
    def on_loadList(btn):
        import ipywidgets as widgets
        from azure.storage.blob import ContainerClient

        global accountName, accountKey, chosenProjectName, container
        clear_output()

        ## connecto to azure blob
        try:
            connection_string = "DefaultEndpointsProtocol=https;AccountName={};AccountKey={};EndpointSuffix=core.windows.net".format(
                accountName, accountKey
            )
            container = ContainerClient.from_connection_string(
                conn_str=connection_string, container_name="aistorage"
            )
            blob_list = container.list_blobs()
            blobNames = list(map(lambda x: x.name, blob_list))
            chosenProjectName = blobNames[0] if len(blobNames) > 0 else ""
            # display(blobNames)
            # Project
            def on_changeProject(projectName):
                global chosenProjectName
                chosenProjectName = projectName["new"]

            ddProject = widgets.Dropdown(
                options=blobNames,
                value=blobNames[0] if len(blobNames) > 0 else "",
                description="",
                disabled=False,
            )
            ddProject.observe(on_changeProject, names="value")
            ## fetch
            def on_fetchProject(btn):
                import pickle
                import pandas as pd
                from aiya.context import context

                global chosenProjectName, container
                content = container.download_blob(blob=chosenProjectName)
                bytesContent = content.content_as_bytes()
                display("featch blob content of " + chosenProjectName)
                # display(content.content_as_text())
                # currProject = pickle.loads(pklProject)
                # for key in currProject['catalogs'].keys():
                #    currProject['catalogs'][key]['content'] = pd.read_json(currProject['catalogs'][key]['content']) if 'content' in currProject['catalogs'][key].keys() else {}
                context.addProject(chosenProjectName, pickle.loads(bytesContent))
                print("Loading done..!!")

            btnFetch = widgets.Button(description="가져오기")
            btnFetch.on_click(on_fetchProject)
            ## display
            display(widgets.HBox([widgets.Label("* 프로젝트 목록: "), ddProject, btnFetch]))
        except:
            display(HTML("Error occurred"))
        ## back to azure main
        def on_back2Main(btn):
            load()

        btnMain = widgets.Button(description="돌아가기")
        btnMain.on_click(on_back2Main)
        display(HTML("<hr"))
        display(btnMain)

    btnLoad = widgets.Button(description="목록 불러오기")
    btnLoad.on_click(on_loadList)

    ## display widgets
    display(HTML("Azure Account Info"))
    display(
        widgets.VBox(
            [
                widgets.HBox([widgets.Label("* Account Name: "), wgtAccountName]),
                widgets.HBox([widgets.Label("* Account Key: "), wgtAccountKey]),
            ]
        )
    )
    display(btnLoad)
    display(HTML("<hr>"))
    display(HTML(uit.backToProject()))


def save():
    import ipywidgets as widgets
    from aiya.context import context

    clear_output()
    currProjectName = context.getCurrProjectName()
    currProject = context.getCurrProject()
    ## save button
    btnSave = widgets.Button(description="저장하기")

    def on_save(btn):
        from aiya.context import context
        from azure.storage.blob import ContainerClient

        connection_string = "DefaultEndpointsProtocol=https;AccountName=ktaiplatform;AccountKey=1f62iMutnMsnKgvaUGD04Sedc1ZaqV6RAjjuj8RVnE9nJXr/DPWNj8sqb5fLKo25mTcw+P5Xnz0O9ebYatuS3A==;EndpointSuffix=core.windows.net"
        container = ContainerClient.from_connection_string(
            conn_str=connection_string, container_name="aistorage"
        )
        currProjectName = context.getCurrProjectName()
        currProject = context.getCurrProject()
        currProject["repository-config"] = {
            "type": "azure-blob",
            "account-name": "ktaiplatform",
            "account-key": "1f62iMutnMsnKgvaUGD04Sedc1ZaqV6RAjjuj8RVnE9nJXr/DPWNj8sqb5fLKo25mTcw+P5Xnz0O9ebYatuS3A==",
            "container-name": "aistorage",
        }
        # for key in currProject['catalogs'].keys():
        #    currProject['catalogs'][key]['content'] = currProject['catalogs'][key]['content'].to_json() if 'content' in currProject['catalogs'][key].keys() else {}
        import pickle

        container.upload_blob(
            data=pickle.dumps(currProject), name=currProjectName, overwrite=True
        )
        display(HTML(">> Successfully saved project on Azure."))

    btnSave.on_click(on_save)

    ## display
    display(HTML("Azure Account & Container Info"))
    display(HTML(" - Account Name: xx<br> - Account Key: xx<br> - Container Name: xx"))
    display(HTML("<hr>"))
    display(HTML("Current Project - " + currProjectName))
    display(currProject)
    display(btnSave)
    display(HTML("<hr>"))
    display(HTML(uit.backToProject()))
