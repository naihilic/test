from IPython.display import display, HTML, clear_output
from aiya.ui import tools as uit

projects = None
s3_client = None
chosenProjectName = None
loadedProjectNames = []


def load():
    from simplecrypt import decrypt
    import ipywidgets as widgets
    from aiya.context.context import context
    import boto3

    global projects, s3_client, chosenProjectName
    # currProjectName = context.currProjectName
    # currProjectName = None
    # currProject = context.currProject
    if context.currUser is None:
        display(HTML("사용자 정보가 없어서 정보를 저장하거나 가져 올 수 없습니다.."))
        return
    currStorage = context.currStorage
    session = boto3.Session(
        aws_access_key_id=currStorage["aws_access_key_id"],
        aws_secret_access_key=currStorage["aws_secret_access_key"],
        aws_session_token=currStorage["aws_session_token"],
    )
    s3_client = session.client(
        service_name="s3", region_name="US", endpoint_url=currStorage["endpoint_url"]
    )
    objects = s3_client.list_objects(
        Bucket="my-bucket", Prefix=context.currUser + "/project/"
    )
    projects = (
        list(
            map(
                lambda obj: {obj["Key"].split("/")[-1].split(".")[0]: obj["Key"]},
                objects["Contents"],
            )
        )
        if "Contents" in objects.keys()
        else []
    )
    display(str(projects))
    chosenProjectName = list(projects[0].keys())[0] if len(projects) > 0 else None
    ddProject = widgets.Dropdown(
        options=list(map(lambda project: list(project.keys())[0], projects)),
        value=chosenProjectName,
        description="",
        disabled=False,
    )

    def on_changeProject(projectName):
        global chosenProjectName
        chosenProjectName = projectName["new"]

    ddProject.observe(on_changeProject, names="value")
    btnLoadProject = widgets.Button(description="가져오기")

    def on_loadProject(btn):
        import pickle

        global projects, s3_client, chosenProjectName

        # display(HTML('TODO: load project of name {} - {}'.format(projectName['new'], list(filter(lambda project: projectName['new'] in project.keys(), projects))[0][projectName['new']])))
        bytesContent = s3_client.get_object(
            Bucket="my-bucket",
            Key=list(
                filter(lambda project: chosenProjectName in project.keys(), projects)
            )[0][chosenProjectName],
        )["Body"].read()
        # display(bytesContent)
        context.addProject(
            chosenProjectName, pickle.loads(decrypt("password", bytesContent))
        )
        loadedProjectNames.append(chosenProjectName)
        load()

    btnLoadProject.on_click(on_loadProject)

    # display output
    clear_output()
    # display(HTML(uit.createNavigationBar('home.project.load-zadara')))
    display(widgets.HBox([widgets.Label("프로젝트: "), ddProject, btnLoadProject]))
    display(HTML("<hr>"))
    for projectName in loadedProjectNames:
        display(HTML(" - {} is loaded".format(projectName)))


def save():
    from simplecrypt import encrypt
    import ipywidgets as widgets
    from aiya.context.context import context

    if context.currUser is None:
        display(HTML("사용자 정보가 없어서 정보를 저장하거나 가져 올 수 없습니다.."))
        return
    currProject = context.currProject
    ## save button
    btnSave = widgets.Button(description="저장하기")

    def on_save(btn):
        from aiya.context.context import context
        import boto3

        currProjectName = context.currProjectName
        currProject = context.currProject
        currStorage = context.currStorage
        session = boto3.Session(
            aws_access_key_id=currStorage["aws_access_key_id"],
            aws_secret_access_key=currStorage["aws_secret_access_key"],
            aws_session_token=currStorage["aws_session_token"],
        )
        s3_client = session.client(
            service_name="s3",
            region_name="US",
            endpoint_url=currStorage["endpoint_url"],
        )
        import pickle

        s3_client.put_object(
            Body=encrypt("password", pickle.dumps(currProject)),
            Bucket=currStorage["bucket"],
            Key=context.currUser + "/project/" + currProjectName + "." + "pkl",
        )
        display(encrypt("password", pickle.dumps(currProject)))
        display(HTML(">> 저장을 완료했습니다."))
        from aiya.project import project

        btnBack = widgets.Button(description="돌아가기", button_color="white")
        btnBack.on_click(project.menu)
        display(btnBack)

    btnSave.on_click(on_save)

    ## display
    clear_output()
    # display(HTML(uit.createNavigationBar('home.project.save-zadara')))
    display(HTML("Storage Info<hr>"))
    display(HTML(str(context.currStorage)))
    display((HTML("<hr>")))
    display(btnSave)
