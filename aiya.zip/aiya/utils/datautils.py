import pandas as pd


def fillnaNumeric(dataFrame):
    df = dataFrame.fillna(dataFrame.mean())
    #### all rows are None
    df = df.fillna(0)
    return df


def fillnaTimeseries(dataFrame):
    df = dataFrame.fillna(method="backfill")
    df = df.fillna(method="ffill")
    #### all rows are None
    df = df.fillna(0)
    return df


def subDict(dict, keys):
    return {key: dict[key] for key in keys}
