import os
import zipfile
import io
import pathlib


def zip_dir(path):
    buffer = io.BytesIO()
    zip_file = zipfile.ZipFile(buffer, "w")
    lib_path = pathlib.Path(path)
    for full, name in get_paths(lib_path):
        zip_file.write(full, name)
    zip_file.close()
    return buffer.getvalue()


def zip_dir_and_save(dir):
    with zipfile.ZipFile(str(dir) + ".zip", "w") as zips:
        for full, name in get_paths(dir):
            zips.write(full, name)
        return pathlib.Path(zips.filename)


def get_paths(root, parent=""):
    for child in root.glob("*"):
        if child.is_file():
            yield child, os.path.join(parent, child.name)
        else:
            yield from get_paths(child, os.path.join(parent, child.name))
