def checkAIdu():
    import os

    return os.path.exists(os.path.join(os.sep, "aihub", "data"))


def makeBacktickName(name):
    if name.isnumeric():
        return "`" + name + "`"
    else:
        return name


def getMetaAndContent(value):
    key = list(value.keys())[0]
    return key, value[key]["metadata"], value[key]["content"]


def getDfFromByte(content, dOption, fileName):
    import chardet
    import pandas as pd
    import io

    lenchk = 1000000 if len(content) > 1000000 else len(content)
    encoding = chardet.detect(content[:lenchk])["encoding"]
    ext = fileName.split(".")[-1]
    excel = ["xlsx", "xls", "xlsm", "xlsb"]
    try:
        if ext in excel:
            return pd.read_excel(io.BytesIO(content), encoding=encoding)
        elif ext == "json":
            return pd.read_json(
                io.BytesIO(content), orient=dOption["orient"], encoding=encoding
            )
        else:
            return pd.read_csv(
                io.BytesIO(content), encoding=encoding, sep=dOption["sep"]
            )
    except Exception:
        return None


def makeCatalogName(fileName):
    name = fileName.split(".")[:-1]
    if name:
        catalogName = ".".join(name)
    else:
        catalogName = fileName
    return catalogName


def get_properRadio(content, dOption, fileName):
    import ipywidgets as widgets
    from aiya.constants import JSON_OPTION, CSV_OPTION

    file_type = fileName.split(".")[-1]
    if file_type == "json":
        return widgets.RadioButtons(
            options=JSON_OPTION,
            description="orient:",
            disabled=False,
            value=dOption["orient"],
        )
    else:
        return widgets.RadioButtons(
            options=CSV_OPTION, description="구분자:", disabled=False, value=dOption["sep"]
        )
