# By naihil
import os

c.NotebookApp.tornado_settings = {"websocket_max_message_size": 500 * 1024 * 1024}
chromePath = "C:/Program Files (x86)/Google/chrome/Application/chrome.exe"
if os.path.exists(chromePath):
    c.NotebookApp.browser = u"" + chromePath + " %s"
