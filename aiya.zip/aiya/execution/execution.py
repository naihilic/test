from IPython.display import display, HTML, clear_output, FileLink
from ipywidgets import (
    Select,
    Button,
    HBox,
    VBox,
    Label,
    Output,
    FileUpload,
    IntSlider,
    FloatLogSlider,
)
from aiya.execution.localmodel import LocalModel
from aiya.context.context import context as ctx
from aiya.ui.tools import createVBoxButtons, createButton
from aiya.ui.tools import display_download
from pathlib import Path

model_output = Output()
config_output = Output()
result_output = Output()
leftOut = Output()
rightOut = Output()
import os


def __clearOutput():
    model_output.clear_output()
    result_output.clear_output()
    config_output.clear_output()


def __on_plot(btn):
    if __getLocalModels():
        __clearOutput()
        model = __getModel(btn.select.index)
        with result_output:
            display(model.plot())


def __on_modelSel(value):
    new_value = value["new"]
    with rightOut:
        clear_output()
        display(HTML("<h4>모델 요약</h4>"))
        display(HBox(__getModelDefination(new_value)))


def __on_download(btn):
    if __getLocalModels():
        from IPython.display import Javascript

        model = __getModel(btn.select.index)
        zip_file_path = model.download()
        display(Javascript('window.open("{0}")'.format(zip_file_path.as_posix())))



def __getFiles(path):
    files = []
    for p in path.iterdir():
        if p.is_file():
            files.append(
                ('files', (p.name, open(p,'rb')))
            )
    return files

def __on_click_deploy(btn):
    import requests
    files = __getFiles(btn.path)
    deploy_url = 'http://{server}/domain/{dname}/model/{mname}/version/{ver}/upload'
    deploy_url = deploy_url.format(server=btn.server.value, dname=btn.domain.value, mname=btn.model.value, ver=btn.version.value)

    response = requests.post(deploy_url, files=files)

    if response.status_code == 200:
        print("업로드 성공")
    else:
        print("업로드 실패" + str(response.status_code))

def __on_deploy(btn):
    if __getLocalModels():
        __clearOutput()
        with model_output:
            from ipywidgets import Text, VBox
            display(HTML('<h3>모델 easy-serve 배포</h3>'))
            model_path = Path(__getLocalModels()[btn.select.index])/'model'


            server = Text(value="localhost:8000", description="server: ")
            dname = Text(value=model_path.parts[1], description="domain: ")
            mname = Text(value=model_path.parts[-1], description="model: ")
            version = Text(value="ver", description="version: ")
            deploy_btn = createButton("배포하기", __on_click_deploy)
            children = [server,dname,mname,version]

            deploy_btn.server=server
            deploy_btn.domain=dname
            deploy_btn.model=mname
            deploy_btn.version=version
            deploy_btn.path = model_path
            deploy_btn.observe(__on_click_deploy)
            display(VBox(children+[deploy_btn]))



def __on_simulate(btn):
    if __getLocalModels():
        from ipywidgets import FloatText, Text, Dropdown, FloatSlider, interact
        import pandas as pd

        __clearOutput()

        with model_output:
            display(HTML("<h3>모델 시뮬레이터</h3>"))
            model = __getModel(btn.select.index)
            df = model.simulate()

            input_desc = model.input_description()
            # display(input_desc)

            input_list = model.simulate().index

            input_type = []
            field_value = []
            # jobBtn = createButton('시뮬레이션 시작', __click_simulate)

            for i in range(0, len(input_list)):
                input_type.append(df["input_features"][i])

            field_variable = []

            for i in range(0, len(input_list)):
                field_variable.append("input_field" + str(i))

            for i, ftr in enumerate(input_desc):
                if ftr["type"] == "numerical" or ftr["type"] == "binary":
                    field_variable[i] = FloatText(
                        value=0.0, description=ftr["name"] + ":", disabled=False
                    )
                elif ftr["type"] == "category":
                    field_variable[i] = Dropdown(
                        options=ftr["vocab"][1:],
                        value=ftr["vocab"][1],
                        description=ftr["name"] + ":",
                        disabled=False,
                    )
                elif ftr["type"] == "text" or ftr["type"] == "date":
                    field_variable[i] = Text(
                        value="",
                        placeholder="",
                        description=ftr["name"] + ":",
                        disabled=False,
                    )
                display(field_variable[i])

            def __change_simulate(change):
                import pandas as pd

                df_model = model
                df_input_list = input_list
                df_field_variable = field_variable

                with result_output:
                    clear_output()
                    test_list = []
                    for i in range(0, len(df_input_list)):
                        test_list.append(df_field_variable[i].value)

                    df = pd.DataFrame(
                        test_list, index=df_input_list, columns=["input_value"]
                    )
                    df = df.T
                    pred = model.prediction(df)
                    display(HTML("<h4>시뮬레이션 결과</h4>"))
                    display(df)
                    display(pred[0])

            for i in range(0, len(field_variable)):
                field_variable[i].observe(__change_simulate, names="value")


def __on_prediction(btn):
    if __getLocalModels():
        __clearOutput()
        catalogs = __get_suitable_catalog()
        jobBtn = createButton("예측 시작", __click_prediction)
        jobBtn.select = catalogs
        jobBtn.model = __getModel(btn.select.index)

        with model_output:
            display(HTML("<h5>" + "예측 데이터 선택" + "</h5>"))
            display(catalogs)
            display(jobBtn)


def __on_retrain(btn):
    if __getLocalModels():
        __clearOutput()
        catalogs = __get_suitable_catalog()
        resume_btn = createButton("학습재개(Resume)", __click_resume)
        reload_btn = createButton("재학습(Reload)", __click_reload)
        resume_btn.select = catalogs
        reload_btn.select = catalogs
        resume_btn.model = __getModel(btn.select.index)
        reload_btn.model = __getModel(btn.select.index)

        pre_trained_info = resume_btn.model.pre_trained_info()

        epochSlider = IntSlider(
            value=pre_trained_info["epoch"],
            min=1,
            max=1000,
            step=1,
            continuous_update=False,
        )
        batchSlider = FloatLogSlider(
            value=pre_trained_info["batch_size"],
            base=2,
            min=0,
            max=20,
            step=1,
            continuous_update=False,
            readout_format="d",
        )

        resume_btn.epoch = epochSlider
        resume_btn.batch = batchSlider
        reload_btn.epoch = epochSlider
        reload_btn.batch = batchSlider

        with model_output:
            display(HTML("<h5>" + "학습 데이터 선택" + "</h5>"))
            display(catalogs)

        with config_output:
            display(HTML("<h5>" + "Training Config" + "</h5>"))
            display(VBox([Label("Epochs"), epochSlider]))
            display(VBox([Label("Batch size"), batchSlider]))

        with result_output:
            display(HBox([resume_btn, reload_btn]))


def __get_suitable_catalog():
    # todo
    return Select(options=ctx.catalogNames)


def __on_delete(btn):
    localModels = __getLocalModels()
    if localModels:
        import shutil

        shutil.rmtree(localModels.pop(btn.select.index))
        btn.select.value = None
        btn.select.options = [x.parts[-1] for x in localModels]
    if localModels:
        btn.select.value = btn.select.options[0]


def __click_prediction(btn):
    model = btn.model
    df = ctx.getCatalogByName(btn.select.value)
    pred, csv = model.prediction(df)
    with result_output:
        clear_output()
        display(HTML("<h5>" + "예측 결과" + "</h5>"))
        display(pred)
        display_download(csv.encode(encoding="utf-16"), "result.csv")


def __click_resume(btn):
    model = btn.model
    config = {"epochs": int(btn.epoch.value), "batch_size": int(btn.batch.value)}
    df = ctx.getCatalogByName(btn.select.value)
    model.resume(df, config)


def __click_reload(btn):
    model = btn.model
    config = {"epochs": int(btn.epoch.value), "batch_size": int(btn.batch.value)}
    df = ctx.getCatalogByName(btn.select.value)
    model.reload(df, config)


def __getModel(idx):
    return LocalModel(__getLocalModels()[idx])


def __getLocalModels():
    return [
        Path(pathname)
        for pathname, dirname, filename in os.walk(".")
        if "training_statistics.json" in filename
    ]


def __getModelDefination(idx):
    if __getLocalModels():
        model = LocalModel(__getLocalModels()[idx])
        return model.preview()
    else:
        return [Label("모델이 없습니다.")]


def menu():
    display(HTML("<h3>" + "AI운영" + "</h3>"))
    display(HBox([leftOut, rightOut]))
    localModels = __getLocalModels()
    selModel = Select(options=[x.parts[-1] for x in localModels], rows=10)
    selModel.layout = {"width": "250px", "height": "200px"}
    selModel.observe(__on_modelSel, names="index")

    btns_info = [
        ("모델 보기", __on_plot),
        ("모델 다운로드", __on_download),
        ("모델로 예측", __on_prediction),
        ("모델 재학습", __on_retrain),
        ("모델 삭제", __on_delete),
        ("모델 시뮬레이터",__on_simulate),
        ("Easy-Serve 배포",__on_deploy)
    ]

    modelBtnBox = createVBoxButtons(btns_info)

    for btn in modelBtnBox.children:
        btn.select = selModel

    with leftOut:
        clear_output()
        display(HTML("<h4> 보유 모델 목록</h4>"))
        display(HBox([selModel, modelBtnBox]))

    with rightOut:
        clear_output()
        display(HTML("<h4>모델 요약</h4>"))
        display(HBox(__getModelDefination(0)))

    display(HTML("<hr>"))
    display(HBox([model_output, config_output]))
    display(result_output)
