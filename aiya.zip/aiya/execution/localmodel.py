import os
from aiya.utils.ziputils import zip_dir_and_save
from pandas import DataFrame
from aiya.utils.datautils import subDict
from ipywidgets import Output
from aiya.automl.aidumodel import AIDUTabularModel, AIDUTimeseriesModel, AIDUTextModel


class LocalModel:
    def __init__(self, resumePath):
        self._resumePath = resumePath
        self._loadPath = resumePath / "model"
        self._zip_path = None
        self.AIDUModel = self._getAIDUModel()
        self._modelDef = self.AIDUModel.loadModelDefinition(self._loadPath)
        self._modelProgress = self.AIDUModel.loadTrainingProgress(self._loadPath)

    def _getAIDUModel(self):
        modelType = self._resumePath.parent.name
        if modelType == "Tabular_Vanilla":
            AIDUModel = AIDUTabularModel()
        elif modelType == "Uni_variate":
            AIDUModel = AIDUTimeseriesModel()
        elif modelType == "Text_Vanilla":
            AIDUModel = AIDUTextModel()
        else:
            AIDUModel = AIDUTabularModel()
        return AIDUModel

    def preview(self):
        from ipywidgets import Output
        from IPython.display import display

        input_df = self.__get_feature_info("input_features")
        output_df = self.__get_feature_info("output_features")
        train_df = self.__get_training_info()

        preview = []
        for df in [input_df, output_df, train_df]:
            out = Output()
            with out:
                display(df)
            preview.append(out)
        return preview

    def simulate(self):
        input_df = self.__get_feature_info("input_features")
        return input_df

    def plot(self):
        self.AIDUModel.plot(
            modelResumePath=self._resumePath, modelLoadPath=self._loadPath
        )

    def download(self):
        self._zip_path = zip_dir_and_save(self._loadPath)
        return self._zip_path

    def __del__(self):
        import time

        if self._zip_path is not None:
            time.sleep(5)
            self._zip_path.unlink()

    def prediction(self, dataFrame):
        pred, csv = self.AIDUModel.predict(
            dataFrame=dataFrame, modelLoadPath=self._loadPath
        )
        return pred, csv

    def pre_trained_info(self):
        modelDef = subDict(self._modelDef["training"], ["epochs"])
        modelDef.update(subDict(self._modelProgress, ["epoch", "batch_size"]))
        return modelDef

    def resume(self, df, config):
        self.AIDUModel.resume(df, config, self._resumePath)

    def reload(self, df, config):
        self.AIDUModel.reload(df, config, self._loadPath)

    def __get_feature_info(self, name):
        f_dict = {dic["name"]: dic["type"] for dic in self._modelDef[name]}
        return DataFrame(f_dict.values(), f_dict.keys(), columns=[name])

    def __get_training_info(self):
        training = subDict(self._modelDef["training"], ["epochs", "batch_size"])
        return DataFrame(training.values(), training.keys(), columns=["training"])

    def input_description(self):
        return self._modelDef["input_features"]
