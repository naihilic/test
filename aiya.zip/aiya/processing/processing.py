from IPython.display import display, HTML, clear_output
from aiya.context.context import context as ctx


def on_changeProject(projectName):
    ctx.changeCurrProject(projectName["new"])
    menu()


def on_changeCatalog(catalogName):
    ctx.changeCurrCatalog(catalogName["new"])
    menu()


def on_changeCatalogType(catalogType):
    ctx.changeCurrCatalogType(catalogType["new"])
    menu()


def on_changeMethod(methodName):
    menu(method=methodName["new"])


def displayData(df, method="Description"):
    if df is None:
        display(HTML("Empty"))
    elif method == "Description":
        display(HTML("1. Info"))
        display(df.info())
        display(HTML("2. Describe"))
        display(df.describe())
        display(HTML("3. Head"))
        display(df.head())
    elif method == "NLP-Korean":
        from aiya.processing.nlp import konlp

        konlp.main()
    else:
        display(df.describe())
        display(HTML("method: (" + method + ")"))


def menu(method="Description"):
    import ipywidgets as widgets
    from aiya.ui import tools as uit
    from aiya import constants
    import pandas as pd

    clear_output()
    processingMethod = constants.PROCESSING_METHODS

    # Project
    ddProject = widgets.Dropdown(
        options=list(ctx.projectNames),
        value=ctx.currProjectName,
        description="",
        disabled=False,
    )
    ddProject.observe(on_changeProject, names="value")
    # Catalog
    # Catalog.1 Catalog Data
    ddCatalog = widgets.Dropdown(
        options=list(ctx.catalogNames),
        value=ctx.currCatalogName,
        description="",
        disabled=False,
    )
    ddCatalog.observe(on_changeCatalog, names="value")
    # Catalog.2 Catalog Type
    ddCatalogType = widgets.Dropdown(
        options=processingMethod.keys(),
        value=ctx.catalogType,
        description="",
        disabled=False,
    )
    ddCatalogType.observe(on_changeCatalogType, names="value")
    # Methods
    ddMethod = widgets.Dropdown(
        options=processingMethod[ctx.catalogType],
        value=method,  # if method in types else type[0]
        description="",
        disabled=False,
    )
    ddMethod.observe(on_changeMethod, names="value")

    # display if data is not empty
    display(HTML("<h1>" + "데이터 가공" + "</h1>"))
    display(HTML("<hr>"))
    display(widgets.HBox([widgets.Label("* 현재 프로젝트: "), ddProject]))
    display(widgets.HBox([widgets.Label("* 현재 카탈로그: "), ddCatalog]))
    display(widgets.HBox([widgets.Label("* 가공 방법: "), ddCatalogType, ddMethod]))
    display(HTML("<hr>"))
    displayData(ctx.content, method=method)
