from IPython.display import display, HTML, clear_output

colCurr = None
methodCurr = None

from konlpy.tag import Kkma

kkma = Kkma()


def main():
    from ipywidgets import (
        widgets,
        interact_manual,
        Label,
        SelectMultiple,
        Select,
        HBox,
        VBox,
        Output,
    )
    from aiya.ui import tools as uit
    from aiya.context import context

    global colCurr, methodCurr

    # get current catalog
    df = context.getCurrProjectCatalogContent()
    colCurr = df.columns[0] if colCurr is None else colCurr
    methodCurr = "형태소" if methodCurr is None else methodCurr

    # select feature to process
    colSelect = Select(
        options=list(df.columns),
        value=colCurr,
        disabled=False,
        Description="Columns",
        rows=10,
    )

    def on_colSelect(change):
        global colCurr
        colCurr = change["new"]
        main()

    colSelect.observe(on_colSelect, names="value")

    # select method to process
    methodSelect = Select(
        options=["형태소", "명사"],
        value=methodCurr,
        disabled=False,
        Description="Methods",
        rows=5,
    )

    def on_methodSelect(change):
        global methodCurr
        methodCurr = change["new"]
        main()

    methodSelect.observe(on_methodSelect, names="value")

    # transform as selected
    btnTransform = widgets.Button(description="변환")

    def on_transform(btn):
        global colCurr, methodCurr
        df = context.getCurrProjectCatalogContent()
        if methodCurr == "형태소":
            df[colCurr + "_pos"] = df[colCurr].apply(
                lambda x: " ".join(
                    map(lambda xx: str(xx[0]) + "_" + str(xx[1]), kkma.pos(x))
                )
            )
        elif methodCurr == "명사":
            df[colCurr + "_nouns"] = df[colCurr].apply(
                lambda x: " ".join(map(lambda xx: str(xx[0]), kkma.nouns(x)))
            )
        main()

    btnTransform.on_click(on_transform)

    # display
    clear_output()
    display(
        HBox(
            [
                VBox([Label("Feature"), colSelect]),
                VBox([Label("Method"), methodSelect, btnTransform]),
            ]
        )
    )
    if df[colCurr].dtype == "object":
        if methodCurr == "형태소":
            display(HTML("현재값: " + df[colCurr].values[0]))
            display(
                HTML(
                    "변경값: "
                    + " ".join(
                        map(
                            lambda xx: str(xx[0]) + "_" + str(xx[1]),
                            kkma.pos(df[colCurr].values[0]),
                        )
                    )
                )
            )  # kkma.pos(df[colCurr].values[0]))))
        elif methodCurr == "명사":
            display(HTML("현재값: " + df[colCurr].values[0]))
            display(HTML("변경값: " + str(kkma.nouns(df[colCurr].values[0]))))
