import sys
import os
import aiya


def customJupyter():
    from os import path, makedirs
    from shutil import copy
    import aiya

    homePath = path.expanduser("~")
    jupyterCustomPath = path.join(homePath, ".jupyter/custom")
    jupyterProfilePath = path.join(homePath, ".jupyter")

    customJsPath = path.join(path.dirname(aiya.__file__), "resources/custom.js")
    customLogoPath = path.join(path.dirname(aiya.__file__), "resources/logo.png")
    customCSSPath = path.join(path.dirname(aiya.__file__), "resources/custom.css")
    configPath = path.join(
        path.dirname(aiya.__file__), "resources/jupyter_notebook_config.py"
    )
    if not path.exists("jupyterCustomPath"):
        makedirs(jupyterCustomPath, exist_ok=True)

    copy(configPath, jupyterProfilePath)

    copy(customJsPath, jupyterCustomPath)
    copy(customLogoPath, jupyterCustomPath)
    copy(customCSSPath, jupyterCustomPath)


def main():
    print("\nAIan Version " + aiya.__version__ + "\n")
    chromePath = "C:/Program Files (x86)/Google/chrome/Application/chrome.exe"
    if os.path.exists(chromePath):
        customJupyter()
        import notebook.notebookapp

        notebook.notebookapp.main()
    else:
        print("\n AIdu 사용을 위해 크롬을 설치하여 주시기 바랍니다.\n")


if __name__ == "__main__":
    main()
